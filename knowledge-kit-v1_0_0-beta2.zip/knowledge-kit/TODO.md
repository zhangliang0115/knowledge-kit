# 待办事项（v1.0.0-beta.2）

状态：✅ 已完成并有测试　🟡 已写但没在真机验证　⬜ 未开始　❓ 需要你决定

## 0. 现在是什么状态
- ✅ Claude Code 和 Claude 桌面版（经本地 MCP 服务）都已支持：读官方记忆、跨项目候选、个人规则（带安全检查和查重）、固化后复发检测、自检、跨项目检索、复习、演示、报告、备份、安装/升级/卸载（含从 0.x 迁移）。`python3 selftest.py` 全部通过。
- 🟡 **所有测试只用模拟数据**，没有在真实 Claude Code 上跑过。这是 beta 的原因。
- ✅ 与 0.x 的关系：旧的蒸馏、晋升脚本和 kb-daily、kb-distill 技能已移除；旧数据保留；旧 CLAUDE.md 规则可导入。0.14.1 的包我另外保留着，想退回可以用。

## 1. 必须在真机验证的官方行为（我只读了官方文档，没实测）
先让 Claude 运行 `kb.py audit` 和 `kb.py report`，大部分能一次性验证：
- 🟡 记忆文件的 frontmatter 字段：`name`、`description`、`type`（user/feedback/project/reference）、`modified`（文档称 2.1.214 起写入）。解析已做宽容处理，格式不符会在自检里报 `format`。
- 🟡 `MEMORY.md` 的读取上限（文档：前 200 行或 25KB）。
- 🟡 **`~/.claude/rules/` 下的个人规则是否对所有项目的新会话生效**。这是整条"固化"链路的前提，只能让用户在新会话里输入 `/memory` 看加载列表。
- 🟡 开关名：`autoMemoryEnabled`、环境变量 `CLAUDE_CODE_DISABLE_AUTO_MEMORY`、`autoMemoryDirectory`。
- 🟡 官方记忆整理（Auto Dream）是否会更新记忆的时间戳。会的话"规则疑似复发"会有误报，目前已标明只是"疑似"。
- 🟡 项目名：从该项目会话 cwd 推断，真实目录结构下是否合理没验证。
- 🟡 三个技能能否被自然语言稳定触发（"今天该做什么""考考我"等）。
- 🟡 **Claude 桌面版接入**（全部只用我写的测试客户端验证过）：配置文件位置 `~/Library/Application Support/Claude/claude_desktop_config.json` 和 `mcpServers` 格式来自公开教程；MCP 协议握手能否被你那个版本的桌面版接受；工具在聊天里能否被调用；桌面版是否会遵守个人偏好里那段"先调用 kb_rules"的话（取决于模型，不保证）。

## 2. 已知局限（不是 bug，是做不到或没做）
- 候选分组靠字面匹配：10 组同义样例召回 7 组、11 组不同义样例误报 0 组（样例是我人工写的，只有 21 组）。纯换说法的做不到，所以 `/kb-promote` 要求 Agent 另外浏览全部 feedback 补看。
- 复习题质量取决于 Agent 的出题，没有自动度量。
- pytest 路径、Python 3.8、GitHub Actions CI 没有实际跑过（沙箱里只跑了 unittest 和 Python 3.12）。

## 3. 多工具支持
你要覆盖 Claude Code、Claude 应用、Kiro IDE/CLI/Crew、opencode，并且"一套知识沉淀"。已确认你用的是 **Claude 桌面版 + Claude Code 命令行**。
- ✅ 第 0 阶段：Claude Code
- ✅ 第 1 阶段：Claude 桌面版（经本地 MCP 服务，双向：读规则和记忆、存笔记）。🟡 没在真机验证。
- ⬜ 手机版和网页版：跑不了本地服务，需要远程服务（要部署、认证），暂不做
- ⬜ 第 3 阶段：opencode、Kiro 的适配器（把确认过的规则同步成各家的常驻规则文件）。已查到的事实：opencode 全局规则 `~/.config/opencode/AGENTS.md`，技能目录会读 `~/.claude/skills/`；Kiro 用 `~/.kiro/steering/` 和 AGENTS.md，但有多个 issue 反映 **Kiro IDE 的全局规则不生效**（约 165 天前，不知道修没修），需要在工作区放真实文件；Kiro Crew 跑在 Kiro CLI 上，自带记忆
- ⬜ 其它工具产生的记忆如何导入（各家格式不同，需要逐个做读取器）

## 4. 需要你决定的事
- ❓ 要不要做成官方插件格式（`.claude-plugin/`）：安装变成一条命令，不再需要 install.sh 和路径替换。我还没核对插件规范。
- ❓ 复习功能保留，还是改用现成的间隔复习插件（xdd、claude-tutor、reSkill）
- ❓ 要不要先试用 claude-mem 或 claude-soul 做对比

## 5. 后续可能做的
- ⬜ 抽样核对：让 Claude 在你机器上抽 10 处你纠正过它的地方，看官方记了没有，用来判断官方记忆漏不漏（**不需要把数据发给我**，你扫一眼回答"漏了几个"）。我们不再自己蒸馏，这一步决定以后还要不要补一个兜底。
- ⬜ 自检增强：格式探针、规则复发的置信度、改动前后的指标对比
- ⬜ 并发保护、版本迁移脚本、许可证（要分享前需要你选定）

## 6. 建议的下一步
1. 安装本包，对 Claude 说"演示一下知识库"，先看它做什么；用桌面版的话再对它说"把知识库接入 Claude 桌面版"
2. 正常使用一两周，不用做额外操作
3. 对 Claude 说"自检一下知识库"，再说"生成反馈报告"，把报告转给我（只有数量和问题代码）。这一步能验证第 1 节的大部分假设；桌面版那条请你自己试一下（在桌面版里说"调用 kb_status 看看"），告诉我通没通、桌面版是什么版本
4. 我据此修正，再推进多工具支持
