#!/usr/bin/env python3
"""MCP 服务（stdio，无第三方依赖）：让 Claude 桌面版读到跨项目的知识，并把笔记存进同一个知识库。

只暴露读和"记笔记"，**不暴露写个人规则**：规则会影响每个 Claude Code 会话，必须留在 Claude Code 里由用户逐条确认
（否则一句网页里的注入指令就可能污染所有项目）。

工具：kb_status、kb_rules、kb_search、kb_memories、kb_candidates、kb_note_add
协议：JSON-RPC 2.0，每行一条消息；stdout 只输出协议消息，日志一律写 stderr。
实现方式：每个工具都调用同目录的 kb.py（参数用列表传递，不经过 shell），行为和命令行完全一致。
"""
import json, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SUPPORTED = ["2025-06-18", "2025-03-26", "2024-11-05"]
MAX_OUT = 20000
TYPES = ["user", "feedback", "project", "reference"]


def _schema(props, required=()):
    return {"type": "object", "properties": props, "required": list(required), "additionalProperties": False}


TOOLS = [
    {"name": "kb_rules", "description": "读取我的个人跨项目规则（已经过我确认）。每次新对话开始时先调用，并遵守这些规则。",
     "inputSchema": _schema({}), "annotations": {"readOnlyHint": True}},
    {"name": "kb_search", "description": "在我所有项目的 Claude Code 记忆和笔记里搜索（所有关键词都要出现）。遇到可能以前碰过的问题时先查。",
     "inputSchema": _schema({"query": {"type": "string", "description": "空格分隔的关键词"},
                             "type": {"type": "string", "enum": TYPES, "description": "只看某类记忆"},
                             "project": {"type": "string", "description": "只看名字里含这段文字的项目"},
                             "limit": {"type": "integer", "minimum": 1, "maximum": 50}}, ["query"]),
     "annotations": {"readOnlyHint": True}},
    {"name": "kb_memories", "description": "列出我的记忆（按更新时间倒序）。",
     "inputSchema": _schema({"type": {"type": "string", "enum": TYPES}, "project": {"type": "string"},
                             "since_days": {"type": "integer", "minimum": 1, "maximum": 3650},
                             "limit": {"type": "integer", "minimum": 1, "maximum": 100}}),
     "annotations": {"readOnlyHint": True}},
    {"name": "kb_candidates", "description": "列出在多个项目里重复出现的纠正（跨项目规则候选）。只读；固化成规则必须在 Claude Code 里由我确认。",
     "inputSchema": _schema({}), "annotations": {"readOnlyHint": True}},
    {"name": "kb_status", "description": "知识库概况：记忆数量、候选数、规则数、下一步建议。",
     "inputSchema": _schema({}), "annotations": {"readOnlyHint": True}},
    {"name": "kb_note_add", "description": "把我明确要求记住的内容存进知识库（Claude Code 之后也能看到）。类型：feedback=纠正或偏好，project=决策或事实，"
                                           "user=关于我本人，reference=外部资料位置。内容里不要包含密钥或口令；只在我明确说“记一下”或做出重要决定时调用。",
     "inputSchema": _schema({"type": {"type": "string", "enum": TYPES},
                             "description": {"type": "string", "description": "一句话，4–200 字"},
                             "body": {"type": "string", "description": "可选的细节，最多 2000 字"},
                             "project": {"type": "string", "description": "可选：这条属于哪个项目或主题"}}, ["type", "description"]),
     "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True}},
]


def run_kb(args):
    r = subprocess.run([sys.executable, str(HERE / "kb.py"), *args], capture_output=True, text=True, stdin=subprocess.DEVNULL, timeout=60)
    out = (r.stdout + ("\n" + r.stderr if r.stderr.strip() else "")).strip() or "（没有输出）"
    if len(out) > MAX_OUT:
        out = out[:MAX_OUT] + "\n…（内容过长，已截断）"
    return out, r.returncode != 0


def _opt(args, flag, v):
    if v not in (None, ""):
        args += [flag, str(v)]


def call_tool(name, a):
    """返回 (文本, 是否出错)。参数一律校验后以列表形式传给 kb.py（"--" 之后的位置参数不会被当成选项）。"""
    if not isinstance(a, dict):
        return "参数必须是对象", True
    t = a.get("type")
    if t is not None and t not in TYPES:
        return f"type 必须是 {', '.join(TYPES)}", True
    for k in ("limit", "since_days"):
        if k in a and (not isinstance(a[k], int) or isinstance(a[k], bool) or a[k] < 1):
            return f"{k} 必须是正整数", True
    for k in ("query", "project", "description", "body"):
        if k in a and not isinstance(a[k], str):
            return f"{k} 必须是字符串", True
    if name == "kb_rules":
        return run_kb(["rules"])
    if name == "kb_status":
        return run_kb(["--json"])
    if name == "kb_candidates":
        return run_kb(["candidates"])
    if name == "kb_search":
        terms = (a.get("query") or "").split()
        if not terms:
            return "query 不能为空", True
        args = ["search"]
        _opt(args, "-t", t); _opt(args, "-p", a.get("project")); _opt(args, "-n", min(a.get("limit", 20), 50))
        return run_kb(args + ["--"] + terms)
    if name == "kb_memories":
        args = ["memories"]
        _opt(args, "-t", t); _opt(args, "-p", a.get("project")); _opt(args, "--since", a.get("since_days")); _opt(args, "-n", min(a.get("limit", 30), 100))
        return run_kb(args)
    if name == "kb_note_add":
        if not t or not a.get("description"):
            return "type 和 description 都是必填", True
        args = ["note", "add"]
        _opt(args, "--body", a.get("body")); _opt(args, "-p", a.get("project"))
        return run_kb(args + ["--", t, a["description"]])
    return f"未知工具：{name}", True


def handle(msg):
    """处理一条 JSON-RPC 消息，返回要发回的消息（通知返回 None）。"""
    if not isinstance(msg, dict):
        return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "无效请求"}}
    mid, method, params = msg.get("id"), msg.get("method"), msg.get("params") or {}
    is_request = "id" in msg and method is not None
    ok = lambda result: {"jsonrpc": "2.0", "id": mid, "result": result}
    err = lambda code, text: {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": text}}
    if method is None:  # 对方发来的响应，忽略
        return None
    if method == "initialize":
        want = params.get("protocolVersion")
        return ok({"protocolVersion": want if want in SUPPORTED else SUPPORTED[0], "capabilities": {"tools": {"listChanged": False}},
                   "serverInfo": {"name": "knowledge-kit", "version": (HERE / "VERSION").read_text().strip() if (HERE / "VERSION").exists() else
                                  ((HERE / ".knowledge-kit").read_text().strip() if (HERE / ".knowledge-kit").exists() else "dev")}})
    if not is_request:  # notifications/initialized、notifications/cancelled 等：不回应
        return None
    if method == "ping":
        return ok({})
    if method == "tools/list":
        return ok({"tools": TOOLS})
    if method == "tools/call":
        name = params.get("name")
        if name not in {t["name"] for t in TOOLS}:
            return err(-32602, f"未知工具：{name}")
        try:
            text, is_err = call_tool(name, params.get("arguments") or {})
        except subprocess.TimeoutExpired:
            text, is_err = "执行超时", True
        except Exception as e:  # 任何内部错误都作为工具错误返回，不让服务崩掉
            text, is_err = f"内部错误：{type(e).__name__}", True
            print(f"[knowledge-kit] {name} 出错：{e!r}", file=sys.stderr)
        return ok({"content": [{"type": "text", "text": text}], "isError": is_err})
    return err(-32601, f"不支持的方法：{method}")


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            out = [{"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "JSON 解析失败"}}]
        else:
            out = [handle(m) for m in (msg if isinstance(msg, list) else [msg])]
        for o in out:
            if o is not None:
                sys.stdout.write(json.dumps(o, ensure_ascii=False) + "\n")
                sys.stdout.flush()


if __name__ == "__main__":
    main()
