#!/usr/bin/env python3
"""官方 auto memory 的只读阅读器 + 跨项目聚类 + 我们自己维护的个人规则文件。

官方记忆（Claude Code 自己写，我们只读不写）：
  ~/.claude/projects/<项目>/memory/MEMORY.md          索引
  ~/.claude/projects/<项目>/memory/feedback_xxx.md    一条记忆，frontmatter 里有 type: user|feedback|project|reference
我们写的只有一个文件：~/.claude/rules/kb-promoted.md（官方的"个人规则目录"，每个会话都会加载）
"""
import hashlib, json, os, re
from datetime import date, datetime
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))
from kbcommon import kb_home, atomic_write, config, check_rule, scan_text

TYPES = ("user", "feedback", "project", "reference")
TYPE_ZH = {"user": "偏好", "feedback": "纠正", "project": "项目", "reference": "参考"}
FM = re.compile(r"\A\ufeff?---[ \t]*\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|\Z)(.*)\Z", re.S)
RULES_HEADER = "# 个人跨项目规则（knowledge-kit 维护，每条都经你确认）"


def claude_dir():
    return Path.home() / ".claude"


def rules_path():
    return claude_dir() / "rules" / "kb-promoted.md"


def settings():
    try:
        d = json.loads((claude_dir() / "settings.json").read_text())
    except Exception:
        return {}
    return d if isinstance(d, dict) else {}


def memory_enabled():
    """(是否开启, 原因)。只看用户级设置和环境变量；项目级开关另算。"""
    if os.environ.get("CLAUDE_CODE_DISABLE_AUTO_MEMORY", "").lower() in ("1", "true", "yes"):
        return False, "环境变量 CLAUDE_CODE_DISABLE_AUTO_MEMORY 已设置"
    if settings().get("autoMemoryEnabled") is False:
        return False, "~/.claude/settings.json 里 autoMemoryEnabled 为 false"
    return True, ""


def memory_roots():
    """[(项目目录, 记忆目录)]。包含默认位置和 autoMemoryDirectory 指定的位置。"""
    roots, seen = [], set()

    def add(proj, mem):
        try:
            key = mem.resolve()
        except OSError:
            return
        if key not in seen and mem.is_dir():
            seen.add(key)
            roots.append((proj, mem))

    custom = settings().get("autoMemoryDirectory")
    if isinstance(custom, str) and custom:
        p = Path(os.path.expanduser(custom))
        if p.is_dir():
            if (p / "MEMORY.md").exists() or any(p.glob("*.md")):
                add(p, p)
            for sub in sorted(x for x in p.iterdir() if x.is_dir()):
                if (sub / "MEMORY.md").exists():
                    add(sub, sub)
    proj = claude_dir() / "projects"
    if proj.is_dir():
        for d in sorted(x for x in proj.iterdir() if x.is_dir()):
            add(d, d / "memory")
    return roots


def project_label(proj_dir, mem_dir):
    """给人看的项目名：优先取该项目会话里 cwd 的最短路径的目录名，否则用目录名。"""
    best = None
    try:
        files = sorted(proj_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:2]
    except OSError:
        files = []
    for f in files:
        try:
            with f.open(errors="ignore") as fh:
                for i, ln in enumerate(fh):
                    if i > 60:
                        break
                    try:
                        o = json.loads(ln)
                    except ValueError:
                        continue
                    c = o.get("cwd") if isinstance(o, dict) else None
                    if isinstance(c, str) and c and (best is None or len(c) < len(best)):
                        best = c
        except OSError:
            pass
    if best:
        return os.path.basename(best.rstrip("/")) or best
    name = proj_dir.name if proj_dir != mem_dir else mem_dir.name
    return name.lstrip("-")[-40:] or "(未命名)"


def _meta(text):
    m = FM.match(text)
    if not m:
        return {}, text
    meta = {}
    for ln in m.group(1).splitlines():
        k, sep, v = ln.partition(":")
        if sep and k.strip() and not ln.startswith((" ", "\t", "-")):
            meta[k.strip().lower()] = v.strip().strip("'\"")
    return meta, m.group(2)


def _date(v, fallback):
    if v:
        try:
            return datetime.fromisoformat(v.replace("Z", "+00:00")).date()
        except ValueError:
            m = re.match(r"(\d{4})-(\d{2})-(\d{2})", v)
            if m:
                try:
                    return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                except ValueError:
                    pass
    return fallback


def parse_entry(path, project, root):
    text = path.read_text(errors="ignore")
    meta, body = _meta(text)
    typ, src = meta.get("type", "").lower(), "frontmatter"
    if typ not in TYPES:
        pre = path.stem.split("_", 1)[0].lower()
        typ, src = (pre, "filename") if pre in TYPES else ("", "none")
    body = body.strip()
    desc = meta.get("description", "")
    if not desc:
        for ln in body.splitlines():
            t = re.sub(r"^[#>\-\*\s]+", "", ln).strip()
            if t:
                desc = t[:200]
                break
    mtime = date.fromtimestamp(path.stat().st_mtime)
    return {"project": project, "file": path.name, "path": str(path), "root": str(root),
            "type": typ, "type_source": src, "name": meta.get("name") or path.stem,
            "description": desc, "body": body,
            "modified": _date(meta.get("modified", ""), mtime).isoformat(),
            "has_modified": bool(meta.get("modified")), "has_frontmatter": bool(meta)}


NOTE_SOURCE = "Claude 桌面版"  # 通过 MCP 或 kb note add 写入的笔记，在跨项目分析里算一个独立来源


def notes_dir():
    return kb_home() / "notes"


def note_add(type_, description, body="", project=None):
    """写一条笔记到 <KB>/notes/，格式与官方记忆相同（frontmatter 里有 type/description/modified），
    所以它和各项目的官方记忆一起参与检索和跨项目聚类。返回 (路径, 是否新建)。"""
    if type_ not in TYPES:
        raise RuleError(f"类型必须是 {' / '.join(TYPES)}（纠正或偏好用 feedback，决策或事实用 project，外部资料用 reference）")
    description = " ".join((description or "").split())
    body = (body or "").strip()
    project = " ".join((project or NOTE_SOURCE).split())
    if not 4 <= len(description) <= 200:
        raise RuleError("描述要 4–200 字：一句话说清楚")
    if len(body) > 2000:
        raise RuleError("正文最多 2000 字")
    if "|" in project or len(project) > 40 or not project:
        raise RuleError("来源名不能含竖线，且不超过 40 字")
    if scan_text(f"{description}\n{body}\n{project}"):
        raise RuleError("拒绝写入：内容里有疑似密钥或口令，请先去掉")
    d = notes_dir()
    for f in sorted(d.glob("*.md")) if d.exists() else []:
        try:
            e = parse_entry(f, project, d)
        except OSError:
            continue
        if e["type"] == type_ and e["project"] == project and (e["description"] == description or similarity(description, e["description"]) >= 0.7):
            return f, False
    h = hashlib.md5(f"{type_}|{description}".encode()).hexdigest()[:6]
    f = d / f"{date.today():%Y%m%d}-{h}.md"
    head = f"---\nname: {f.stem}\ndescription: {description}\ntype: {type_}\nproject: {project}\nmodified: {datetime.now():%Y-%m-%dT%H:%M:%SZ}\n---\n"
    atomic_write(f, head + (body + "\n" if body else ""))
    return f, True


def load_entries():
    """所有官方记忆条目（不含 MEMORY.md 索引），加上 <KB>/notes/ 里的笔记。"""
    out = []
    for proj_dir, mem in memory_roots():
        label = project_label(proj_dir, mem)
        for f in sorted(mem.glob("*.md")):
            if f.name.lower() == "memory.md":
                continue
            try:
                out.append(parse_entry(f, label, mem))
            except OSError:
                continue
    nd = notes_dir()
    for f in sorted(nd.glob("*.md")) if nd.is_dir() else []:
        try:
            meta, _ = _meta(f.read_text(errors="ignore"))
            e = parse_entry(f, meta.get("project") or NOTE_SOURCE, nd)
            e["from_notes"] = True
            out.append(e)
        except OSError:
            continue
    return out


# ---------------------------------------------------------------- 相似度与聚类
_STOP = {"the", "and", "for", "that", "this", "with", "not", "use", "always", "never", "when", "should", "before", "after"}
# 纠正类句子里几乎每条都有的字眼，不能当作"说的是同一件事"的证据
_STOP_ZH = {"不要", "要用", "需要", "不能", "可以", "应该", "必须", "除非", "自己", "一个", "我会", "我们", "这个", "那个", "如果",
            "所有", "每次", "总是", "始终", "之前", "之后", "然后", "明确", "要求", "禁止", "统一", "使用", "请用", "别给", "要在"}


def tokens(s):
    s = s.lower()
    out = {w for w in re.findall(r"[a-z0-9_]{3,}", s) if w not in _STOP}
    for run in re.findall(r"[\u4e00-\u9fff]+", s):
        out.update(run[i:i + 2] for i in range(len(run) - 1))
    return out - _STOP_ZH


MIN_SHARED = 2  # 至少有这么多个共同片段才算相似，避免只因一个常见词就被归到一起


def overlap(ta, tb):
    """重合系数：共同片段数 / 较短那条的片段数。适合"一条长一条短、说的是同一件事"的情况；
    实测比 Jaccard 好得多（同义的中文纠正，Jaccard 在 0.3 阈值下一条都召回不了）。"""
    shared = len(ta & tb)
    return shared / min(len(ta), len(tb)) if ta and tb and shared >= MIN_SHARED else 0.0


def similarity(a, b):
    return overlap(tokens(a), tokens(b))


def duplicate_score(a, b):
    """判重：重合系数（一条长一条短也能识别）。比 Jaccard 更适合改写过的同一条规则。"""
    return similarity(a, b)


def entry_text(e):
    """用于比较的文本：只用描述（没有描述才用正文开头）。不用 name：官方的 name 常是 feedback_xxx 这种标识，
    会让所有条目都虚假相似。"""
    return e["description"] or e["body"][:160]


def clusters(entries, types=("feedback",), threshold=None, min_projects=None, rules=None):
    """把相似的记忆归成一组；只返回出现在 min_projects 个以上项目里的组。
    两种连接方式：①两条的字面重合度够高；②同一个主题词出现在 topic_projects（默认 3）个以上项目里
    （三个项目都提到同一个词，不太可能是巧合）。这只是粗筛，最终要由 Agent 判断是不是真的同一件事。"""
    cfg = config()
    thr = (threshold if threshold is not None else cfg["similarity"] / 100)
    minp = min_projects or cfg["min_projects"]
    es = [e for e in entries if e["type"] in types]
    parent = list(range(len(es)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        parent[find(i)] = find(j)

    toks = [tokens(entry_text(e)) for e in es]
    for i in range(len(es)):
        for j in range(i + 1, len(es)):
            if overlap(toks[i], toks[j]) >= thr:
                union(i, j)
    # ②主题词：出现在多个项目里、但又不是到处都有的词
    by_token = {}
    for i, t in enumerate(toks):
        for w in t:
            by_token.setdefault(w, []).append(i)
    cap = max(6, len(es) // 10)
    topics = {}
    for w, idx in by_token.items():
        projs = {es[i]["project"] for i in idx}
        if len(projs) >= cfg["topic_projects"] and len(idx) <= cap and (re.search(r"[\u4e00-\u9fff]", w) or len(w) >= 4):
            for i in idx[1:]:
                union(idx[0], i)
            topics.setdefault(find(idx[0]), []).append(w)
    groups = {}
    for i in range(len(es)):
        groups.setdefault(find(i), []).append(es[i])
    root_topics = {}
    for r, ws in topics.items():
        root_topics[find(r)] = ws
    rules = rules if rules is not None else rules_list()
    out = []
    for root, members in groups.items():
        projects = sorted({m["project"] for m in members})
        if len(projects) < minp:
            continue
        members.sort(key=lambda m: m["modified"], reverse=True)
        rep = members[0]
        key = "|".join(sorted(f"{m['project']}/{m['file']}" for m in members))
        topic_words = sorted(root_topics.get(find(es.index(rep)), []))
        # 已被现有规则覆盖：任一成员与规则相似，或规则里直接出现了这一组的主题词
        covered = next((i + 1 for i, r in enumerate(rules)
                        if any(similarity(entry_text(m), r) >= thr for m in members) or any(w in r for w in topic_words)), None)
        out.append({"id": hashlib.md5(key.encode()).hexdigest()[:6], "projects": projects, "size": len(members),
                    "text": rep["description"] or rep["name"], "covered_by": covered,
                    "topic": topic_words[:3],
                    "members": [{"project": m["project"], "file": m["file"], "description": m["description"],
                                 "modified": m["modified"]} for m in members]})
    out.sort(key=lambda c: (-len(c["projects"]), -c["size"], c["id"]))
    return out


# ---------------------------------------------------------------- 个人规则文件
class RuleError(Exception):
    pass


def rules_list():
    p = rules_path()
    if not p.exists():
        return []
    return [ln[2:].strip() for ln in p.read_text(errors="ignore").splitlines() if ln.startswith("- ") and ln[2:].strip()]


def _rules_write(items):
    atomic_write(rules_path(), RULES_HEADER + "\n\n" + "\n".join(f"- {r}" for r in items) + ("\n" if items else ""))


def _log(rec):
    p = kb_home() / "rules" / "promoted-log.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    rec = dict(rec, date=date.today().isoformat())
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def read_log():
    p = kb_home() / "rules" / "promoted-log.jsonl"
    out = []
    if p.exists():
        for ln in p.read_text(errors="ignore").splitlines():
            try:
                r = json.loads(ln)
            except ValueError:
                continue
            if isinstance(r, dict):
                out.append(r)
    return out


def rules_add(text, sources=None, cluster=None, force=False, allow_similar=False):
    text = " ".join((text or "").split())
    if not text:
        raise RuleError("规则不能为空")
    problem = check_rule(text)
    if problem and not force:
        raise RuleError(f"已拒绝写入：{problem}。请人工核对原文；确认安全后可加 --force。")
    if scan_text(text):
        raise RuleError("已拒绝写入：规则里含疑似密钥或口令，请先去掉。")
    items = rules_list()
    for i, r in enumerate(items, 1):
        if r == text or (not allow_similar and duplicate_score(text, r) >= 0.6):
            raise RuleError(f"与第 {i} 条规则重复：{r}")
    items.append(text)
    _rules_write(items)
    _log({"action": "add", "text": text, "sources": sources or [], "cluster": cluster})
    return len(items)


def rules_remove(n):
    items = rules_list()
    if not 1 <= n <= len(items):
        raise RuleError(f"没有第 {n} 条规则（现有 {len(items)} 条）")
    text = items.pop(n - 1)
    _rules_write(items)
    _log({"action": "remove", "text": text})
    return text


LEGACY_RULE = re.compile(r"^-\s*(?:[^：:\n]{1,40})[：:]\s*(.+)$")


def legacy_rules():
    """旧版本（0.x）写进 ~/.claude/CLAUDE.md「## 自动晋升规则」小节的规则文本。"""
    p = claude_dir() / "CLAUDE.md"
    if not p.exists():
        return []
    out, on = [], False
    for ln in p.read_text(errors="ignore").splitlines():
        if ln.startswith("## "):
            on = ln.strip() == "## 自动晋升规则"
            continue
        m = LEGACY_RULE.match(ln.strip()) if on else None
        if m:
            out.append(m.group(1).strip())
    return out


def effectiveness(entries=None, threshold=None):
    """固化后是否还在被纠正：返回 [{rule, date, hits:[...]}]，只含有疑似复发的规则。
    线索：固化之后又被更新过、且仍与规则相似的 feedback 记忆。注意官方的记忆整理（Auto Dream）也会更新时间，
    所以只是"疑似"，需要人（或 Agent）打开文件确认。"""
    entries = entries if entries is not None else load_entries()
    thr = threshold if threshold is not None else max(config()["similarity"] / 100, 0.3)
    live, added = set(rules_list()), {}
    for r in read_log():
        if r.get("action") == "add" and r.get("text") in live:
            added[r["text"]] = r
    out = []
    for text, rec in added.items():
        since = rec.get("date", "")
        hits = [{"project": e["project"], "file": e["file"], "modified": e["modified"]}
                for e in entries
                if e["type"] == "feedback" and e["modified"] > since and similarity(text, entry_text(e)) >= thr]
        if hits:
            out.append({"rule": text, "date": since, "hits": hits})
    return out
