#!/usr/bin/env python3
"""knowledge-kit 统一入口。由 Claude Code 执行：用户用自然语言提需求，Agent 来跑这些命令。

官方 auto memory（Claude Code 自己记的笔记）是数据来源，我们只读；这里补的是官方没做的跨项目层。

  kb [--json]                      今天的状态和下一步（不带参数）
  kb memories [-t 类型] [-p 项目] [--since 天] [--json]   看官方记忆（user|feedback|project|reference）
  kb search 词1 [词2 ...] [-t 类型] [-p 项目] [-n 条数]   跨项目检索官方记忆和旧版笔记
  kb candidates [--json] [--all]   同一条纠正出现在多个项目里 → 跨项目规则候选
  kb rules                         列出个人跨项目规则（~/.claude/rules/kb-promoted.md）
  kb rules add "规则" [--cluster ID] [--force]   写入一条（用户确认之后）
  kb rules remove N                删除第 N 条
  kb rules migrate                 把旧版写在 CLAUDE.md「自动晋升规则」里的规则导入规则文件
  kb audit [--json]                自检：官方记忆是否正常、规则是否有效、体积是否超限、有无泄密
  kb quiz today|add|grade          复习题（间隔重复）
  kb doctor                        安装体检
  kb report                        生成脱敏的诊断报告，方便反馈问题
  kb backup                        备份我们自己的数据（规则日志、复习进度）
  kb note add 类型 "一句话" [--body 细节] [-p 来源]   记一条笔记（桌面版通过 MCP 也是调这个）；类型 feedback|project|user|reference
  kb connect status|desktop|remove|instructions   接入 Claude 桌面版（本地 MCP 服务，需用户同意并重启桌面版）
  kb demo                          用模拟数据演示整条流程（临时沙箱，不碰真实数据）
  kb where                         知识库位置和版本
"""
import argparse, json, re, subprocess, sys, tarfile
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import official as of
from kbcommon import kb_home, atomic_write, scan_text, config

HERE = Path(__file__).resolve().parent
KB = kb_home()
PASS_THROUGH = {"doctor": "doctor.py", "quiz": "quiz.py", "demo": "demo.py", "connect": "connect.py"}
LEGACY_DIRS = ("inbox", "decisions", "pitfalls", "playbooks", "reviews", "archive")


def version():
    for p in (KB / ".knowledge-kit", HERE / "VERSION"):
        if p.exists():
            return p.read_text().strip()
    return "未知"


def short(s, n=110):
    s = " ".join((s or "").split())
    return s if len(s) <= n else s[:n - 1] + "…"


# ------------------------------------------------------------------ 状态
def read_json(p, default):
    try:
        return json.loads(p.read_text())
    except Exception:
        return default


def collect():
    import quiz
    entries = of.load_entries()
    enabled, why = of.memory_enabled()
    rules = of.rules_list()
    cands = [c for c in of.clusters(entries, rules=rules) if not c["covered_by"]]
    state = quiz.load()
    due = sum(1 for it in state.values() if it.get("due", "9999") <= date.today().isoformat())
    la = read_json(KB / "review" / "last-audit.json", {})
    try:
        age = (date.today() - date.fromisoformat(la["date"])).days
    except Exception:
        age = None
    by_type = {t: sum(1 for e in entries if e["type"] == t) for t in of.TYPES}
    return {"entries": entries, "enabled": enabled, "why": why, "projects": len({e["project"] for e in entries}),
            "by_type": by_type, "candidates": len(cands), "rules": len(rules), "due": due, "audit_age": age}


def next_step(s):
    """(代码, 对用户说的话)"""
    if not s["enabled"]:
        return "enable_memory", f"官方 auto memory 被关闭了（{s['why']}）。请你自己输入 /memory 打开开关，这是内置命令我没法代你执行"
    if not s["entries"]:
        return "first_run", "官方记忆里还没有内容：正常用 Claude Code 几天，它会自己记笔记；之后再对我说「今天该做什么」"
    if s["candidates"]:
        return "promote", "对 Claude 说「看看有哪些跨项目的纠正可以固化成规则」（/kb-promote）"
    if s["due"]:
        return "quiz", "对 Claude 说「考考我」（/kb-quiz）"
    if s["audit_age"] is None or s["audit_age"] > 30:
        return "audit", "对 Claude 说「自检一下知识库」"
    return "done", "都没问题 ✔"


def status(as_json=False):
    s = collect()
    code, say = next_step(s)
    if as_json:
        print(json.dumps({"kb": str(KB), "version": version(), "auto_memory_enabled": s["enabled"],
                          "projects": s["projects"], "memories": len(s["entries"]), "by_type": s["by_type"],
                          "cross_project_candidates": s["candidates"], "rules": s["rules"], "due_questions": s["due"],
                          "days_since_audit": s["audit_age"], "next": {"code": code, "say": say}},
                         ensure_ascii=False, indent=1))
        return
    print(f"知识库：{KB}（v{version()}）\n")
    if not s["enabled"]:
        print("官方记忆  ✘ 已关闭")
    elif s["entries"]:
        bt = "、".join(f"{of.TYPE_ZH[t]} {n}" for t, n in s["by_type"].items() if n)
        print(f"官方记忆  ✔ {s['projects']} 个项目，共 {len(s['entries'])} 条（{bt or '类型未识别'}）")
    else:
        print("官方记忆  还没有内容")
    print(f"跨项目候选  {s['candidates']} 条纠正出现在多个项目里，等你决定" if s["candidates"] else "跨项目候选  没有")
    print(f"个人规则  {s['rules']} 条（{of.rules_path()}）")
    print(f"复习      {s['due']} 道题到期" if s["due"] else "复习      今天没有到期的题")
    print("自检      " + ("从没做过" if s["audit_age"] is None else f"{s['audit_age']} 天前"))
    print(f"\n→ 下一步：{say}")


# --------------------------------------------------------- memories / search
def _filter(entries, a):
    out = entries
    types = [t.strip() for t in (a.type or "").split(",") if t.strip()]
    if types:
        out = [e for e in out if e["type"] in types]
    if a.project:
        out = [e for e in out if a.project.lower() in e["project"].lower()]
    if getattr(a, "since", None):
        cut = (date.today() - timedelta(days=a.since)).isoformat()
        out = [e for e in out if e["modified"] >= cut]
    return out


def _check_types(a):
    for t in [t.strip() for t in (a.type or "").split(",") if t.strip()]:
        if t not in of.TYPES:
            raise SystemExit(f"类型必须是 {' / '.join(of.TYPES)}，收到“{t}”")


def memories(rest):
    ap = argparse.ArgumentParser(prog="kb memories")
    ap.add_argument("-t", "--type", help="user|feedback|project|reference，可用逗号分隔")
    ap.add_argument("-p", "--project")
    ap.add_argument("--since", type=int, help="只看最近 N 天更新过的")
    ap.add_argument("-n", type=int, default=50)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(rest)
    _check_types(a)
    es = sorted(_filter(of.load_entries(), a), key=lambda e: e["modified"], reverse=True)
    if a.json:
        print(json.dumps([{k: e[k] for k in ("project", "file", "type", "name", "description", "modified")} for e in es[:a.n]],
                         ensure_ascii=False, indent=1))
        return
    if not es:
        print("没有符合条件的官方记忆。")
        return
    for e in es[:a.n]:
        print(f"[{e['project']}] {of.TYPE_ZH.get(e['type'], '未分类')} {e['modified']}  {short(e['description'] or e['name'])}  ({e['file']})")
    if len(es) > a.n:
        print(f"…还有 {len(es) - a.n} 条，用 -n {len(es)} 全部显示。")


def search(rest):
    ap = argparse.ArgumentParser(prog="kb search", description="所有词都要出现，忽略大小写")
    ap.add_argument("terms", nargs="+")
    ap.add_argument("-t", "--type")
    ap.add_argument("-p", "--project")
    ap.add_argument("-n", type=int, default=20)
    a = ap.parse_args(rest)
    _check_types(a)
    terms, hits = [t.lower() for t in a.terms], []
    for e in sorted(_filter(of.load_entries(), a), key=lambda e: e["modified"], reverse=True):
        blob = f"{e['name']} {e['description']} {e['body']}".lower()
        if all(t in blob for t in terms):
            line = next((l.strip() for l in e["body"].splitlines() if any(t in l.lower() for t in terms)), e["description"])
            hits.append(f"[{e['project']}] {of.TYPE_ZH.get(e['type'], '未分类')} {e['modified']}  {short(e['description'] or e['name'])}\n    {e['path']}\n    ↳ {short(line, 140)}")
    if not a.type and not a.project:  # 旧版（0.x）留下的笔记也能查
        for sub in LEGACY_DIRS:
            d = KB / sub
            for f in sorted(d.rglob("*.md"), reverse=True) if d.exists() else []:
                for i, ln in enumerate(f.read_text(errors="ignore").splitlines(), 1):
                    if ln.strip() and all(t in ln.lower() for t in terms):
                        hits.append(f"[旧版笔记] {f.relative_to(KB)}:{i}  {short(ln.strip(), 140)}")
    if not hits:
        print("没有找到。换个关键词试试；官方记忆只在 Claude 认为值得记时才会写。")
        return
    for h in hits[:a.n]:
        print(h)
    if len(hits) > a.n:
        print(f"…还有 {len(hits) - a.n} 条，用 -n {len(hits)} 全部显示，或加更多关键词缩小范围。")


def note(rest):
    ap = argparse.ArgumentParser(prog="kb note")
    ap.add_argument("action", choices=["add"])
    ap.add_argument("type")
    ap.add_argument("description")
    ap.add_argument("--body", default="")
    ap.add_argument("-p", "--project")
    a = ap.parse_args(rest)
    try:
        f, new = of.note_add(a.type, a.description, a.body, a.project)
    except of.RuleError as e:
        raise SystemExit(str(e))
    print(("已记录：" if new else "已有相同的笔记：") + str(f))


# ---------------------------------------------------- candidates / rules
def candidates(rest):
    ap = argparse.ArgumentParser(prog="kb candidates")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--all", action="store_true", help="包含已被现有规则覆盖的")
    ap.add_argument("--threshold", type=int, help="字面重合度 0-100（默认取配置，25）")
    ap.add_argument("--types", default="feedback", help="默认只看 feedback；可加 user")
    a = ap.parse_args(rest)
    cs = of.clusters(of.load_entries(), types=tuple(a.types.split(",")),
                     threshold=None if a.threshold is None else a.threshold / 100)
    if not a.all:
        cs = [c for c in cs if not c["covered_by"]]
    if a.json:
        print(json.dumps(cs, ensure_ascii=False, indent=1))
        return
    if not cs:
        print("没有跨项目的重复纠正。（同一条纠正至少要出现在 %d 个项目里）" % config()["min_projects"])
        return
    for c in cs:
        mark = f"（已被第 {c['covered_by']} 条规则覆盖）" if c["covered_by"] else ""
        topic = f"  主题词：{'、'.join(c['topic'])}" if c.get("topic") else ""
        print(f"#{c['id']}  {len(c['projects'])} 个项目：{'、'.join(c['projects'])}{topic}  {mark}")
        for m in c["members"]:
            print(f"    - [{m['project']}] {short(m['description'], 100)}  ({m['modified']})")
    print("\n字面粗筛可能把不相关的归到一起，也会漏掉换了说法的；Agent 要逐组核对是不是真的同一件事，再用 kb memories -t feedback 补看漏网的。\n确认某组要固化后，把它概括成一句可执行的规则，再用 kb rules add 写入。")


def rules(rest):
    ap = argparse.ArgumentParser(prog="kb rules")
    ap.add_argument("action", nargs="?", default="list", choices=["list", "add", "remove", "migrate"])
    ap.add_argument("arg", nargs="?")
    ap.add_argument("--cluster")
    ap.add_argument("--force", action="store_true", help="绕过安全检查（先人工核对原文）")
    ap.add_argument("--allow-similar", action="store_true", help="明知与已有规则相近仍要写入")
    a = ap.parse_args(rest)
    try:
        if a.action == "list":
            items = of.rules_list()
            if not items:
                print(f"还没有个人跨项目规则。文件位置：{of.rules_path()}")
            for i, r in enumerate(items, 1):
                print(f"{i}. {r}")
        elif a.action == "add":
            if not a.arg:
                raise SystemExit('用法：kb rules add "一句可执行的规则" [--cluster ID]')
            sources = []
            if a.cluster:
                c = next((c for c in of.clusters(of.load_entries(), rules=[]) if c["id"] == a.cluster), None)
                if not c:
                    raise SystemExit(f"找不到候选 #{a.cluster}（先运行 kb candidates）")
                sources = [f"{m['project']}/{m['file']}" for m in c["members"]]
            n = of.rules_add(a.arg, sources, a.cluster, a.force, a.allow_similar)
            print(f"已写入 {of.rules_path()}（现共 {n} 条）：\n  - {' '.join(a.arg.split())}\n新开的会话里生效。")
        elif a.action == "remove":
            if not (a.arg or "").isdigit():
                raise SystemExit("用法：kb rules remove N（N 见 kb rules）")
            print("已删除：", of.rules_remove(int(a.arg)))
        else:  # migrate
            old, added, skipped = of.legacy_rules(), 0, []
            if not old:
                print("CLAUDE.md 里没有旧版写入的「自动晋升规则」，无需迁移。")
                return
            for r in old:
                try:
                    of.rules_add(r, ["legacy:CLAUDE.md"], None, True)
                    added += 1
                except of.RuleError as e:
                    skipped.append(f"{short(r, 60)} → {e}")
            print(f"已导入 {added} 条，跳过 {len(skipped)} 条。" + "".join(f"\n  跳过：{s}" for s in skipped))
            print("旧小节还留在 ~/.claude/CLAUDE.md 里（和新文件会重复加载）。确认无误后，请 Agent 征得你同意再删除那个小节。")
    except of.RuleError as e:
        raise SystemExit(str(e))


# ------------------------------------------------------------------ audit
def audit_findings():
    """[(严重度, 代码, 标题, 详情, 建议)]，严重度 error|warn|info。"""
    F = []
    add = lambda sev, code, title, detail="", fix="": F.append({"severity": sev, "code": code, "title": title, "detail": detail, "fix": fix})
    enabled, why = of.memory_enabled()
    entries = of.load_entries()
    roots = of.memory_roots()
    if not enabled:
        add("error", "memory_off", "官方 auto memory 已关闭", why, "用户输入 /memory 打开开关（内置命令，Agent 无法代劳）")
    sessions = sum(1 for _ in (of.claude_dir() / "projects").glob("*/*.jsonl")) if (of.claude_dir() / "projects").is_dir() else 0
    if enabled and not roots:
        if sessions >= 5:
            add("warn", "no_memory", f"有 {sessions} 个会话，却没有任何官方记忆目录", "可能是版本不支持、被项目级设置关闭，或 autoMemoryDirectory 指向了别处", "让用户输入 /memory 看看开关和目录")
        else:
            add("info", "no_memory", "还没有官方记忆", "用几天后 Claude 会自己记")
    if entries and not any(e["type"] for e in entries):
        add("warn", "format", f"读到 {len(entries)} 个记忆文件，但没有一个能识别类型", "官方文件格式可能变了（原来靠 frontmatter 的 type 字段）", "运行 kb report 把结果反馈给作者")
    elif entries and not any(e["has_modified"] for e in entries):
        add("info", "no_modified", "记忆文件没有 modified 时间戳", "Claude Code 2.1.214 以下不写这个字段，时间只能用文件修改时间", "")
    for proj_dir, mem in roots:
        idx = mem / "MEMORY.md"
        if idx.exists():
            raw = idx.read_bytes()
            lines, size = len(raw.splitlines()), len(raw)
            label = of.project_label(proj_dir, mem)
            if lines > 200 or size > 25 * 1024:
                add("error", "index_over", f"项目「{label}」的 MEMORY.md 超出读取上限（{lines} 行 / {size // 1024}KB）", "超出部分每次启动都不会加载", "让 Claude 在该项目里精简索引：每条一行，细节放进主题文件")
            elif lines > 160 or size > 20 * 1024:
                add("warn", "index_near", f"项目「{label}」的 MEMORY.md 接近上限（{lines}/200 行）", "", "提醒 Claude 合并或删除过期条目")
    cs = of.clusters(entries, rules=of.rules_list())
    open_c = [c for c in cs if not c["covered_by"]]
    if open_c:
        add("info", "candidates", f"有 {len(open_c)} 组跨项目重复的纠正没处理", "、".join(c["id"] for c in open_c[:5]), "对 Claude 说「看看有哪些跨项目的纠正可以固化成规则」")
    for r in of.effectiveness(entries):
        hits = "、".join(f"{h['project']}/{h['file']}" for h in r["hits"][:3])
        add("warn", "rule_recurs", f"规则固化后疑似仍被纠正：{short(r['rule'], 50)}", f"{r['date']} 固化；之后更新过的相关记忆：{hits}。官方的记忆整理也会更新时间，需要打开文件确认",
            "确认是真复发的话：把规则写得更具体并加正反例；必须强制执行的改用 hook")
    rl = of.rules_list()
    if len(rl) > 40:
        add("warn", "rules_long", f"个人规则已有 {len(rl)} 条", "规则越多越稀释，官方建议每个文件控制在 200 行以内、越具体越好", "合并或删掉不再出现的")
    claude_md = of.claude_dir() / "CLAUDE.md"
    if claude_md.exists():
        n = len(claude_md.read_text(errors="ignore").splitlines())
        if n > 200:
            add("warn", "claude_md_long", f"全局 CLAUDE.md 有 {n} 行", "超过 200 行会降低遵循度", "让用户运行官方 /doctor prompt-audit，把只和部分代码有关的内容挪进路径规则或技能")
        if of.legacy_rules():
            add("info", "legacy_rules", "旧版写进 CLAUDE.md 的「自动晋升规则」还在", "可导入新的规则文件，统一管理", "kb rules migrate，之后征得同意再删旧小节")
    cut = (date.today() - timedelta(days=config()["stale_days"])).isoformat()
    stale = [e for e in entries if e["type"] == "feedback" and e["modified"] < cut]
    if stale:
        add("info", "stale", f"{len(stale)} 条纠正记忆超过 {config()['stale_days']} 天没更新", "可能已过期", "让 Claude 检查是否还适用，不适用的删掉")
    try:
        from connect import desktop_installed, desktop_connected
        if desktop_installed() and not desktop_connected():
            add("info", "desktop_not_connected", "检测到 Claude 桌面版，但还没接入知识库", "桌面版里的 Claude 看不到跨项目知识，也没法把笔记存进来",
                "征得同意后运行 kb connect desktop，再请用户完全重启桌面版")
    except Exception:
        pass
    leaks = []
    for e in entries:
        if scan_text(e["body"] + " " + e["description"]):
            leaks.append(f"{e['project']}/{e['file']}")
    if rl and scan_text("\n".join(rl)):
        leaks.append("个人规则文件")
    if leaks:
        add("error", "secret", f"{len(leaks)} 处疑似含密钥或口令", "、".join(leaks[:5]), "打开文件删除；用 kb doctor 之外不要复述内容")
    import quiz
    due = sum(1 for it in quiz.load().values() if it.get("due", "9999") <= date.today().isoformat())
    if due > 30:
        add("warn", "quiz_backlog", f"{due} 道复习题到期", "积压太多会放弃", "只做最旧的 10 道，其余推迟")
    order = {"error": 0, "warn": 1, "info": 2}
    F.sort(key=lambda f: order[f["severity"]])
    return F


def audit(rest):
    as_json = "--json" in rest
    F = audit_findings()
    counts = {s: sum(1 for f in F if f["severity"] == s) for s in ("error", "warn", "info")}
    atomic_write(KB / "review" / "last-audit.json", json.dumps({"date": date.today().isoformat(), "counts": counts,
                                                                "codes": [f["code"] for f in F]}, ensure_ascii=False))
    if as_json:
        print(json.dumps({"counts": counts, "findings": F}, ensure_ascii=False, indent=1))
    else:
        mark = {"error": "✘", "warn": "⚠", "info": "·"}
        for f in F:
            print(f"{mark[f['severity']]} {f['title']}" + (f"\n    {f['detail']}" if f["detail"] else "") + (f"\n    → {f['fix']}" if f["fix"] else ""))
        print(f"\n自检完成：{counts['error']} 个错误，{counts['warn']} 个警告，{counts['info']} 条提示。" if F else "自检完成：没有发现问题 ✔")
    return 1 if counts["error"] else 0


def report(rest):
    """脱敏诊断报告：只有版本、数量、问题代码，不含任何记忆内容或项目名。"""
    import platform
    s = collect()
    F = audit_findings()
    L = [f"# knowledge-kit 诊断报告 ({date.today()})", "",
         f"- 版本 {version()}，Python {platform.python_version()}，{platform.system()}",
         f"- 官方 auto memory：{'开启' if s['enabled'] else '关闭'}；项目 {s['projects']}，记忆 {len(s['entries'])}（{', '.join(f'{t}={n}' for t, n in s['by_type'].items())}）",
         f"- 类型来源：frontmatter {sum(1 for e in s['entries'] if e['type_source'] == 'frontmatter')}，文件名 {sum(1 for e in s['entries'] if e['type_source'] == 'filename')}，无法识别 {sum(1 for e in s['entries'] if e['type_source'] == 'none')}",
         f"- 有 modified 字段的记忆：{sum(1 for e in s['entries'] if e['has_modified'])}",
         f"- 跨项目候选 {s['candidates']}，个人规则 {s['rules']}，到期复习题 {s['due']}", "", "## 自检发现"]
    L += [f"- [{f['severity']}] {f['code']}" for f in F] or ["- 无"]
    text = "\n".join(L) + "\n"
    atomic_write(KB / "work" / "report.md", text)
    print(text)


def backup():
    dst_dir = KB.parent / f"{KB.name}-backups"
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / f"{KB.name}-{datetime.now():%Y%m%d-%H%M%S}.tar.gz"

    def skip(ti):  # work/ 是可重建的中间产物，.upgrade-backup 是工具本身的旧版本
        parts = Path(ti.name).parts
        return None if len(parts) > 1 and parts[1] in ("work", ".upgrade-backup") else ti

    with tarfile.open(dst, "w:gz") as tf:
        tf.add(KB, arcname=KB.name, filter=skip)
    rules_file = of.rules_path()
    print(f"已备份到 {dst}（{dst.stat().st_size // 1024} KB）" + (f"\n注意：个人规则文件 {rules_file} 不在知识库里，没有包含；它是纯文本，可以另外复制。" if rules_file.exists() else ""))


COMMANDS = {"note": note, "memories": memories, "search": search, "candidates": candidates, "rules": rules,
            "audit": audit, "report": report, "backup": lambda r: backup(),
            "status": lambda r: status("--json" in r),
            "where": lambda r: print(f"知识库：{KB}\n版本：{version()}")}


def main():
    if len(sys.argv) < 2:
        status()
        return 0
    if sys.argv[1] == "--json":
        status(True)
        return 0
    cmd, rest = sys.argv[1], sys.argv[2:]
    if cmd in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    if cmd in PASS_THROUGH:
        script = KB / PASS_THROUGH[cmd]
        script = script if script.exists() else HERE / PASS_THROUGH[cmd]
        return subprocess.call([sys.executable, str(script), *rest])
    if cmd in COMMANDS:
        r = COMMANDS[cmd](rest)
        return r if isinstance(r, int) else 0
    print(f"未知命令：{cmd}\n")
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
