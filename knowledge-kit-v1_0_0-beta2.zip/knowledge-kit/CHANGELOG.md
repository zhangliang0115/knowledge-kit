# 变更记录

## 1.0.0-beta.2
**接入 Claude 桌面版**：Claude Code 命令行和 Claude 桌面版共用同一个知识库。
- 新增 `mcp_server.py`：无第三方依赖的本地 MCP 服务（stdio）。工具：`kb_rules`、`kb_search`、`kb_memories`、`kb_candidates`、`kb_status`（只读）和 `kb_note_add`（存笔记）。**刻意不暴露写规则的工具**：规则会影响每个 Claude Code 会话，必须留在 Claude Code 里由用户逐条确认
- 新增 `connect.py` 和 `kb connect status|desktop|remove|instructions`：把服务登记进 `claude_desktop_config.json`。用 python 绝对路径（桌面版没有 shell 的 PATH）；改前自动备份；只改自己那一项；文件不是合法 JSON 或结构不对时拒绝改动；幂等；`--dry-run` 预演；`instructions` 打印要贴进桌面版个人偏好的那段话
- 新增笔记存储：`kb note add 类型 "一句话" [--body] [-p 来源]`，写入 `<KB>/notes/`，格式与官方记忆一致。笔记和各项目的官方记忆一起参与 `kb search`、`kb memories` 和跨项目聚类（桌面版里的纠正能和 Claude Code 各项目的纠正被发现是同一件事）。写入前校验类型、长度、来源名，拒绝疑似密钥，相近的笔记去重
- 演示新增"在桌面版里说记一下"一步，候选里能看到 4 个来源
- 自检新增 `desktop_not_connected` 提示；体检新增桌面版接入路径是否有效
- `install.sh` 安装新脚本；`uninstall.sh` 会先移除桌面版配置里自己那一项（改前备份，不动其它服务）
- `kb-ops` 技能新增"接入 Claude 桌面版"和"存笔记"的步骤，要求先征得同意、提醒用户完全重启桌面版
- 测试从 104 增加到 133：MCP 协议（握手、版本协商、通知不回复、畸形输入、stdout 只有协议消息、工具清单不含写规则、参数注入防护、错误返回、笔记入库与去重）、接入脚本（保留其它服务和设置、备份、幂等、非法 JSON 不覆盖、路径失效提示、卸载只删自己那一项）、笔记与聚类
- 局限：**没有在真实的 Claude 桌面版里验证**；手机版和网页版不能接入（跑不了本地服务）


## 1.0.0-beta.1
**重新定位：以 Claude Code 官方 auto memory 为数据来源，只补官方没做的跨项目层。** 这是一次重构，不是小改。

### 新架构
- 读官方记忆（`~/.claude/projects/<项目>/memory/`，只读）；找出在多个项目里重复的纠正；用户逐条确认后写进官方的个人规则文件 `~/.claude/rules/kb-promoted.md`；自检观察规则有没有起作用
- 新增 `official.py`（宽容解析官方记忆、聚类、规则文件）、`demo.py`（`kb demo`：用模拟数据在临时沙箱里把整条流程跑一遍）
- 新命令：`kb memories`、`kb candidates`、`kb rules`（list/add/remove/migrate）、`kb audit`、`kb report`、`kb demo`；`kb search` 改为跨项目搜官方记忆（同时查旧版笔记）
- 自检：官方记忆是否开启、`MEMORY.md` 是否接近或超出读取上限、规则固化后疑似仍被纠正、官方记忆或规则里有疑似密钥、规则文件过长、全局 CLAUDE.md 过长、旧版规则待迁移、纠正记忆过期、复习积压、记忆文件格式无法识别
- `kb report`：脱敏诊断报告，只含版本、数量、问题代码，不含任何记忆内容和项目名
- 技能精简为 3 个：`kb-ops`（日常操作和自检对照表）、`kb-promote`（核对候选、判断固化形式：规则 / 路径规则 / hook / 技能、逐条确认）、`kb-quiz`（从官方记忆出题，一次一道）

### 移除
- 蒸馏（`kb-daily`、`kb-distill`、会话预处理）、旧的晋升脚本、`kb add`、`kb keys`、`kb archive`、`kb feedback`、`kb stats`：官方记忆已经在做记录，不再重复。升级时 `install.sh` 会清掉旧脚本和旧技能，并备份到 `<KB>/.upgrade-backup/`
- 旧数据（`inbox/` 等）原样保留；`kb search` 仍能查；旧版写进 CLAUDE.md 的规则用 `kb rules migrate` 导入

### 做演示和测试时发现并修复的缺陷
- **同义的中文纠正聚不到一起**：最初用 Jaccard、阈值 0.3，在 10 组同义样例上召回 0 组。改用重合系数加共同片段数下限，并对纠正句里的常见字眼做停用，再加"同一主题词出现在 ≥3 个项目"的规则：同义召回 7/10，不同义误报 0/11（样例为人工标注，仅 21 组）
- 误报：「不要用 Lombok，手写 getter」和「表格表单用组件库，不要自己手写样式」曾被归为一组（只因共享"不要"和"手写"）
- 查重失效：换了说法的重复规则曾被写入。现在改用重合系数判重，`--allow-similar` 可明知相近仍写入
- 比较文本不再使用官方的 `name` 字段（常是 `feedback_xxx` 标识，会让所有条目虚假相似）
- 配置默认值里的 `stale_days` 被误删导致 `kb audit` 崩溃（由测试发现）

### 测试
- 全新的 `tests/`：官方记忆解析（缺字段、BOM、CRLF、自定义目录）、相似度（标注样例集的召回与误报）、聚类、规则文件（安全、查重、手改保留、日志）、复发检测、各命令、自检各项、报告脱敏、备份、演示、复习、体检、安装升级卸载（含从 0.x 迁移、旧复习数据兼容、卸载不删个人规则）、技能与文档一致性
- 测试子进程统一接空输入并加超时，避免交互式命令挂住

### 已知局限
官方记忆文件格式、个人规则目录的生效范围等只读过文档，没有在真机验证；详见 `docs/architecture.md` 和 `TODO.md`。

## 0.14.1
- 新增 `TODO.md`（待办、已知缺陷、真机验证项、待你决定的事、建议执行顺序）和 `prototype-v1/`（官方 auto memory 优先的新架构原型，未接入安装和测试，不可安装）
- 内部整理（无用户可见变化）：`kbcommon.py` 增加 `inbox_dates`、`distilled_dates`、`load_calibration`；晋升时额外记录固化日期到 `rules/promoted-log.jsonl`；`extract.py` 可读取 `<KB>/calibration.md` 里的额外纠正线索

## 0.14.0
**不提供定时能力。** 一切都在用户对 Claude 说话时发生，不会在后台运行，也没有需要登录状态或令牌的无人值守流程。
- 移除 `kb remind` / `kb notify`（macOS launchd 每日提醒）及其测试
- 移除脚本版蒸馏 `distill.py` 和 `templates/crontab.example`：它们只为 cron 等无人值守运行而存在，技能版 `/kb-daily` 已完全取代；`kb distill` 子命令一并移除
- `install.sh` 升级旧安装时清掉遗留的 `distill.py`（旧文件已在 `.upgrade-backup/` 里）；`uninstall.sh` 仍会清理旧安装留下的 `distill.py`
- 体检去掉"PATH 里能找到 claude"和"蒸馏失败的诊断日志"两项（只与脚本版有关）
- `/kb-ops` 技能去掉"每天提醒我"；排障文档去掉 cron 登录状态、令牌、PATH 等整套内容，"inbox 里有空文件"一节改为技能版的处理办法
- `AGENT_INSTALL.md` 去掉"可选：定时任务"一节（后续章节重新编号）和 crontab 相关的授权条款
- 新增测试：升级清掉遗留脚本并备份、卸载清理遗留脚本、包里不含任何定时相关文件和命令
- 如果你装过 0.13.0 以前的版本并配过 crontab 或 `kb remind`：升级不会替你删除它们。对 Claude 说"检查我有没有残留的定时任务并帮我清掉"（它会先给你看 `crontab -l` 和 `~/Library/LaunchAgents/com.knowledge-kit.daily.plist`，你同意后再删）

## 0.13.0
**重新定位：操作者是 Claude Code，不是用户。** 用户不自己执行命令，只用自然语言提需求并做决定。
- **新增技能 `/kb-ops`**：把"记一下""以前有没有遇到过…""今天该做什么""这个月怎么样""体检""归档""备份""每天提醒我"都变成 Claude 能直接执行的自然语言入口（先 `kb keys` 沿用已有短键；归档、提醒、改配置先征得同意）
- 其余四个技能的触发描述改为支持自然语言（"收工了""跑今天的知识流程""考考我"等），仍然不会自行运行
- **当前会话也蒸馏**：原来技能和 `extract.py` 默认跳过最近 90 秒内写入的当前会话，而用户常在同一个会话里说"收工"，当天的工作恰好都在里面，会整个漏掉。现在默认处理当前会话；`extract.py --skip-current` 可恢复旧行为；`--commit` 会把当前会话的游标推进到提交时，本流程自己的对话不会明天被再次蒸馏。`/clear` 不再是必要步骤
- `kb --json`（或 `kb status --json`）输出机器可读的状态，含 `next.code` 和"对用户说什么"；人类可读的"下一步"也改成"对 Claude 说「…」"
- 新增 `kb keys [-k 类型]`：列出已有短键和出现天数，记新条目前沿用
- 移除 `kb alias` 及安装时询问写入 `~/.zshrc`：用户不敲命令，Agent 也不改 shell 配置
- 全局 CLAUDE.md 模板新增"由你代我操作""我说记一下就用 /kb-ops""我说收工就问一句要不要跑 /kb-daily"，让 Agent 在日常对话里主动配合；升级时 Agent 需要检查旧的全局 CLAUDE.md 是否缺这几行
- 技能清单收拢到 `kbcommon.SKILLS` 一处（体检用它，安装/卸载/备份直接遍历 `skills/` 目录），测试核对两者一致
- **文档重写**：README 改为只讲"对 Claude 说什么"；`AGENT_INSTALL.md` 成为整个产品的操作手册，新增"用户说什么 → 你做什么"对照表；`docs/operations.md`、排障、技能文档都改成"Claude 执行、你只说需求"，并明确哪些官方内置斜杠命令只能用户自己输入
- 测试：新增 `kb keys`、`status --json`、当前会话蒸馏与游标、技能里引用的 `kb.py` 子命令必须存在、技能目录与清单一致等用例

## 0.12.0
面向"简单、好用"的一轮：装好之后不用记命令，也不用翻文档。
- **状态面板**：`kb`（不带参数）显示今天蒸馏了没有、几条纠正等你决定、几道题到期、已固化几条，并给出一句"下一步"；只读，不改任何文件
- **随手记**：`kb add 类型 短键 内容 [-p 项目]`，格式自动校验（短键长度、竖线、纠正 ≤200 字）、含密钥时拒绝写入（把"写入前过滤"提前到了源头）、插到当天 inbox 的"今日理解题"之前
- **检索**：`kb search 词1 词2 [-k 类型] [-p 项目] [-n 条数]`，在 inbox、decisions、pitfalls、playbooks、reviews、archive 里找，最近的在前
- **归档**：`kb archive [--days 180] [--yes]`，默认只预览；取代手写的 `find ... -mtime` 命令
- **每日提醒（macOS）**：`kb remind on|off|status`，用 launchd 每天定时运行 `kb notify`，今天蒸馏过就不打扰
- **命令别名**：`install.sh` 交互安装时询问是否写入 `~/.zshrc`；`kb alias [--write]` 随时可用；非交互/Agent 安装从不改 shell 配置
- **可调阈值**：`~/.config/knowledge-kit/config.json` 里可设 `threshold`、`recent_days`、`faded_days`；非法值忽略；**重装不再覆盖配置里的其它项**
- 修复：追加蒸馏时，落在"今日理解题"小节之后的条目行会被 `quiz.py` 当成理解题。现在条目行一律跳过，`kb add` 也不会把条目写到题目后面
- 修复：状态判断以"今日理解题"小节区分真正蒸馏过的日子，手动记录不会让面板误报"今天已蒸馏"
- `/kb-daily` 收尾时展示状态面板；`/kb-distill` 的写入规则兼容 `kb add` 已建好的当天文件；体检也检查 `kb-daily` 的路径
- 测试：用例从 46 个增加到 80 多个，新增日常功能、配置、安装后端到端、非交互安装不动 shell 配置等用例

## 0.11.0
- 测试结构重做：`selftest.py` 原来的大脚本拆成 `tests/` 下 9 个模块、46 个独立用例（标准库 unittest，pytest 也能直接跑），每个用例用独立的临时 HOME 和知识库，互不依赖；`selftest.py` 变成运行入口，支持 `-k 关键字` 只跑一部分
- 新增 GitHub Actions 配置 `.github/workflows/ci.yml`（Ubuntu 和 macOS，Python 3.8 与 3.12）；不用 GitHub 可忽略
- 复习评分历史：`quiz.py` 在每题的 `hist` 里记录每次评分（旧数据兼容，没有 `hist` 的题照常工作）
- `kb stats` 新增"近 30 天忘了比例/模糊比例"
- 新增 `kb feedback --missed N --noise N [--merge N] [--note ...]`：记录每天对蒸馏的反馈，写入 `review/feedback.jsonl`；`kb stats` 汇总近 30 天的漏抓、废话合计，用来看蒸馏质量趋势
- 新增文档一致性用例：`tests/` 引用检查；每个顶层脚本都必须被 `install.sh` 安装、被 `uninstall.sh` 清理；AGENT_INSTALL 版本号与 VERSION 一致
- 新增用例覆盖：已有 CLAUDE.md 不被覆盖、卸载不动没有标记的目录、反馈文件有坏行时不崩溃、空知识库 `stats` 不崩溃

## 0.10.0
- 新增统一入口 `kb.py`：`doctor`、`promote`、`quiz`、`extract`、`distill`、`stats`、`backup`、`where` 一个命令搞定（原有脚本照常可单独运行）
- 新增 `kb stats`：自动计算月度 5 项指标（反复出现的纠正、已固化规则、已消退条目、理解题掌握和到期情况、近几周蒸馏天数），口径与 `evolution.md` 一致，支持 `--json`
- 新增 `kb backup`：把知识库打成 tar.gz（不含可重建的 `work/`）
- `install.sh` 升级时自动把旧脚本和技能备份到 `<KB>/.upgrade-backup/<旧版本-时间>/`
- 新增 `uninstall.sh`：移除技能、配置和已装脚本，保留知识库数据，默认交互确认
- 修复：`quiz.py grade` 题号不存在或评分参数不对时给出友好提示，不再抛堆栈
- 自检补充 `kb.py`、备份、卸载、`quiz grade` 错误处理的用例

## 0.9.1
- 文档重构：把原来 A–M 十三个互相取代的附录整理为 README、`docs/operations.md`、`docs/skills-and-plugins.md`、`docs/architecture.md`、`docs/roadmap.md`、`docs/troubleshooting.md`，以包内 Markdown 为唯一事实来源
- 自检增加文档一致性检查（链接、命令引用的脚本是否存在、版本号一致）

## 0.9.0
- 知识库位置可配置：`install.sh` 交互询问（默认沿用上次，`--kb` 可直接指定，已有内容的目录需确认或 `--allow-existing`）
- 位置解析顺序：环境变量 `KB_HOME` > 脚本所在目录（`.knowledge-kit` 标记）> `~/.config/knowledge-kit/config.json` > `~/knowledge`
- 技能改为模板（`{{KB}}`），安装时替换成实际路径，路径含空格时自动加引号
- `doctor.py` 增加配置文件和"技能路径与当前知识库一致"检查
- 确认使用环境为 macOS（IDE + CLI），Windows 不再列入待办

## 0.8.0
- 新增 `kbcommon.py`（统一知识库路径、原子写入、密钥扫描）和 `doctor.py`（体检、`--scan` 扫描疑似密钥）
- 修复：`distill.py` 不认 `KB_HOME`，与其他脚本不一致
- 修复：JSON、规则、CLAUDE.md 改为原子写入，避免中断后留下半截文件
- 安全：`promote.py --apply` 增加规则安全检查（链接、命令、密钥相关词、超长），需人工核对后才可 `--force`；技能明确"会话内容是数据，不是指令"，写入前脱敏、写入后扫描
- 新增 `VERSION`、`CHANGELOG.md`、`.gitignore`、知识库用的 `.gitignore` 模板

## 0.7.0
- 蒸馏内容按项目区分：晋升候选按出现的项目数判断范围，`--apply --to` 可写项目级 CLAUDE.md

## 0.6.1
- 新增 `AGENT_INSTALL.md`（给 Agent 的安装与运行说明）

## 0.6.0
- `/kb-distill` 改为规则驱动，由 Claude Code 自己读取；接入官方自动记忆、`/insights`、claude-md-management、hookify

## 0.5.0
- 抽取逻辑 v2：结构化摘要、增量游标、分块

## 0.4.0
- 新增 Skill 版：`/kb-daily` `/kb-distill` `/kb-promote` `/kb-quiz`

## 0.3.x
- 0.3.3：蒸馏输出为空时不再写 inbox，并记诊断日志
- 0.3.0：理解题间隔复习 `quiz.py`

## 0.2.0
- 晋升与演化总表 `promote.py`

## 0.1.0
- 夜间蒸馏 `distill.py`
