#!/usr/bin/env python3
"""体检：检查安装是否完整、技能路径是否对、官方记忆能否读取。数据层面的问题用 kb audit。

python3 doctor.py   # 有 ✘ 时退出码为 1
"""
import json, shlex, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from kbcommon import kb_home, SKILLS, RETIRED_SKILLS, RETIRED_SCRIPTS

KB = kb_home()
SCRIPTS = ["official.py", "quiz.py", "kbcommon.py", "doctor.py", "kb.py", "mcp_server.py", "connect.py"]
bad = 0


def ck(ok, name, hint="", warn=False):
    global bad
    mark = "✔" if ok else ("⚠" if warn else "✘")
    if not ok and not warn:
        bad += 1
    print(f"{mark} {name}" + (f"  → {hint}" if hint and not ok else ""))


def valid_json(p):
    try:
        json.loads(p.read_text())
        return True
    except Exception:
        return False


def main():
    home = Path.home()
    ck(sys.version_info >= (3, 8), f"python {sys.version.split()[0]}", "需要 3.8 以上")
    ck(KB.is_dir(), f"知识库目录 {KB}", "先运行 install.sh")
    conf = home / ".config" / "knowledge-kit" / "config.json"
    ck(conf.exists() and valid_json(conf), "配置文件 ~/.config/knowledge-kit/config.json", "重新运行 install.sh", warn=True)
    for d in ("rules", "review"):
        ck((KB / d).is_dir(), f"  子目录 {d}/", "重新运行 install.sh")
    miss = [s for s in SCRIPTS if not (KB / s).exists()]
    ck(not miss, "脚本已安装", "缺少 " + "、".join(miss) + "，重新运行 install.sh")
    old = [s for s in RETIRED_SCRIPTS if (KB / s).exists()]
    ck(not old, "没有旧版遗留脚本", "旧脚本：" + "、".join(old) + "，重新运行 install.sh 会清掉（已自动备份）", warn=True)
    miss = [s for s in SKILLS if not (home / ".claude" / "skills" / s / "SKILL.md").exists()]
    ck(not miss, f"{len(SKILLS)} 个技能已安装", "缺少 " + "、".join(miss) + "，重新运行 install.sh 并重启 Claude Code")
    oldsk = [s for s in RETIRED_SKILLS if (home / ".claude" / "skills" / s).exists()]
    ck(not oldsk, "没有旧版遗留技能", "旧技能：" + "、".join(oldsk) + "，重新运行 install.sh 会清掉", warn=True)
    stale = []
    for s in SKILLS:
        f = home / ".claude" / "skills" / s / "SKILL.md"
        if f.exists():
            txt = f.read_text()
            if "{{KB}}" in txt or shlex.quote(str(KB)) not in txt:
                stale.append(s)
    ck(not stale, "技能里的知识库路径与当前一致", "技能指向的位置不对：" + "、".join(stale) + "。重新运行 install.sh（知识库位置变过时必须重装）")
    import official as of
    enabled, why = of.memory_enabled()
    ck(enabled, "官方 auto memory 已开启", f"{why}。需要用户自己输入 /memory 打开", warn=True)
    ck(bool(of.memory_roots()), "找到官方记忆目录", "还没有也正常（用几天后才有）；若用了很久还没有，运行 kb audit 看原因", warn=True)
    import connect
    if connect.desktop_installed():
        if connect.desktop_connected():
            e = connect.load_config()["mcpServers"][connect.NAME]
            fine = Path(e.get("command", "")).exists() and bool(e.get("args")) and Path(e["args"][0]).exists()
            ck(fine, "Claude 桌面版的接入路径有效", "python 或服务脚本的路径已失效（知识库搬过家？），重新运行 kb connect desktop", warn=True)
        else:
            ck(False, "已接入 Claude 桌面版", "检测到桌面版但没接入；需要的话征得同意后运行 kb connect desktop", warn=True)
    rp = of.rules_path()
    if rp.exists():
        ck(len(of.rules_list()) > 0, f"个人规则文件可读（{len(of.rules_list())} 条）", f"{rp} 里没有以“- ”开头的规则行", warn=True)
    for p in (KB / "review" / "state.json", KB / "review" / "last-audit.json"):
        if p.exists():
            ck(valid_json(p), f"{p.relative_to(KB)} 是合法 JSON", "文件已损坏，备份后删除，会自动重建")
    print("\n体检完成：" + ("全部通过。" if not bad else f"有 {bad} 项需要处理。"))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
