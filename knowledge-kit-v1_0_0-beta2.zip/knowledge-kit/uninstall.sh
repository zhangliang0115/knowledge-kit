#!/usr/bin/env bash
# knowledge-kit 卸载：移除技能、配置和知识库里的脚本；你的数据（rules、review 等）和个人规则文件不会被删除。
#   bash uninstall.sh          交互确认
#   bash uninstall.sh --yes    跳过确认（Agent 执行时用，务必先向用户确认）
set -e
YES=""
for a in "$@"; do
  case "$a" in
    --yes) YES=1 ;;
    *) echo "未知参数: $a"; exit 2 ;;
  esac
done

CONF="$HOME/.config/knowledge-kit/config.json"
KB="${KB_HOME:-}"
if [ -z "$KB" ] && [ -f "$CONF" ]; then
  KB="$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('kb_home',''))" "$CONF" 2>/dev/null || true)"
fi
[ -z "$KB" ] && KB="$HOME/knowledge"

echo "将要执行："
echo "  1. 删除技能  ~/.claude/skills/ 下本工具安装的 kb-* 技能"
echo "  2. 删除配置  ~/.config/knowledge-kit/"
if [ -e "$KB/.knowledge-kit" ]; then
  echo "  3. 删除 $KB 里的脚本（*.py）、.knowledge-kit 标记和 .upgrade-backup/；并移除在 Claude 桌面版配置里登记的 knowledge-kit 一项（先备份）"
else
  echo "  3. （$KB 里没有 .knowledge-kit 标记，不会动该目录）"
fi
echo "不会删除：知识库里的数据；个人规则文件 ~/.claude/rules/kb-promoted.md（是你确认过的规则，不想要了自己删）；~/.claude/CLAUDE.md。"
if [ -z "$YES" ]; then
  if [ -t 0 ]; then
    read -r -p "继续？[y/N] " YN
    case "$YN" in y|Y) ;; *) echo "已取消。"; exit 1 ;; esac
  else
    echo "非交互模式需要加 --yes 才会执行。"; exit 1
  fi
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
for sd in "$HERE"/skills/*/; do
  rm -rf "$HOME/.claude/skills/$(basename "$sd")"
done
for d in kb-daily kb-distill; do  # 旧版本安装的技能
  rm -rf "$HOME/.claude/skills/$d"
done
rm -rf "$HOME/.config/knowledge-kit"
if [ -e "$KB/.knowledge-kit" ]; then
  # 先移除我们在 Claude 桌面版配置里登记的那一项（只删自己的，改之前自动备份），否则桌面版会一直尝试启动不存在的服务
  [ -f "$KB/connect.py" ] && KB_HOME="$KB" python3 "$KB/connect.py" remove --quiet || true
  for f in official.py quiz.py kbcommon.py doctor.py kb.py demo.py mcp_server.py connect.py distill.py promote.py extract.py; do
    rm -f "$KB/$f"
  done
  rm -rf "$KB/.upgrade-backup" "$KB/__pycache__"
  rm -f "$KB/.knowledge-kit"
fi
echo "已卸载。数据仍在 $KB。"
echo "如需彻底清理：手动删除该目录；个人规则文件在 ~/.claude/rules/kb-promoted.md。"
