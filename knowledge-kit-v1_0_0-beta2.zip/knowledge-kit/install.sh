#!/usr/bin/env bash
# knowledge-kit 安装：询问知识库位置，放好脚本、技能和模板（兼容 macOS 自带的 bash 3.2）
#   bash install.sh                      交互安装，会询问知识库位置
#   bash install.sh --kb ~/Documents/ai-kb   直接指定位置（无交互，Agent 安装时用）
#   --allow-existing   允许使用已有内容的目录（不会改动你已有的文件，只新增本工具的子目录和文件）
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
CONF_DIR="$HOME/.config/knowledge-kit"
CONF="$CONF_DIR/config.json"
KB_ARG=""; ALLOW_EXISTING=""
while [ $# -gt 0 ]; do
  case "$1" in
    --kb) KB_ARG="$2"; shift 2 ;;
    --allow-existing) ALLOW_EXISTING=1; shift ;;
    *) echo "未知参数: $1"; exit 2 ;;
  esac
done

# 默认位置：已有配置 > ~/knowledge
DEFAULT="$HOME/knowledge"
if [ -f "$CONF" ]; then
  OLD="$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('kb_home',''))" "$CONF" 2>/dev/null || true)"
  [ -n "$OLD" ] && DEFAULT="$OLD"
fi
if [ -n "$KB_ARG" ]; then
  CHOICE="$KB_ARG"
elif [ -t 0 ]; then
  echo "知识库放在哪里？（存放规则日志、复习进度和自检记录；也可以指向 Obsidian 库里的某个文件夹）"
  read -r -p "目录 [$DEFAULT]: " CHOICE
  CHOICE="${CHOICE:-$DEFAULT}"
else
  CHOICE="$DEFAULT"
  echo "非交互模式，使用 $CHOICE（可用 --kb 指定其它位置）"
fi
KB="$(python3 -c "import os,sys;print(os.path.abspath(os.path.expanduser(sys.argv[1])))" "$CHOICE")"

# 目录已有内容且不是本工具建的：先确认
if [ -d "$KB" ] && [ -n "$(ls -A "$KB" 2>/dev/null)" ] && [ ! -e "$KB/.knowledge-kit" ] && [ -z "$ALLOW_EXISTING" ]; then
  if [ -t 0 ] && [ -z "$KB_ARG" ]; then
    read -r -p "$KB 已有内容。仍然使用吗？只会新增本工具的子目录和文件，不改动已有文件 [y/N]: " YN
    case "$YN" in y|Y) ;; *) echo "已取消。"; exit 1 ;; esac
  else
    echo "$KB 已有内容。确认可以使用后，加 --allow-existing 重新运行。"; exit 1
  fi
fi
mkdir -p "$KB" || { echo "无法创建 $KB"; exit 1; }
[ -w "$KB" ] || { echo "$KB 不可写"; exit 1; }
if [ -f "$CONF" ] && [ -n "${OLD:-}" ] && [ "$OLD" != "$KB" ]; then
  echo "注意：知识库位置从 $OLD 改为 $KB。旧位置的数据不会自动搬过来，需要的话请手动移动后再运行体检。"
fi

# 1.0.0 起不再提供的技能和脚本（升级时清理；清单与 kbcommon.py 的 RETIRED_* 保持一致，测试会核对）
RETIRED_SKILLS="kb-daily kb-distill"
RETIRED_SCRIPTS="distill.py promote.py extract.py"

# 升级前备份：已装过本工具时，把旧脚本和技能存到 $KB/.upgrade-backup/（只备份工具本身，数据不动）
if [ -e "$KB/.knowledge-kit" ]; then
  OLDV="$(cat "$KB/.knowledge-kit" 2>/dev/null || echo unknown)"
  BK="$KB/.upgrade-backup/$OLDV-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$BK/skills"
  for f in "$KB"/*.py; do [ -f "$f" ] && cp "$f" "$BK/"; done
  for sd in "$HERE"/skills/*/; do
    d="$(basename "$sd")"
    [ -d "$HOME/.claude/skills/$d" ] && cp -R "$HOME/.claude/skills/$d" "$BK/skills/"
  done
  for d in $RETIRED_SKILLS; do
    [ -d "$HOME/.claude/skills/$d" ] && cp -R "$HOME/.claude/skills/$d" "$BK/skills/"
  done
  echo "已备份旧版本（$OLDV）到 $BK"
fi

# 目录结构、脚本、标记
mkdir -p "$KB/rules" "$KB/review" "$KB/work"
cp "$HERE/official.py" "$HERE/quiz.py" "$HERE/kbcommon.py" "$HERE/doctor.py" "$HERE/kb.py" "$HERE/demo.py" "$HERE/mcp_server.py" "$HERE/connect.py" "$KB/"
chmod +x "$KB/official.py" "$KB/quiz.py" "$KB/doctor.py" "$KB/kb.py" "$KB/demo.py" "$KB/mcp_server.py" "$KB/connect.py"
# 旧版本遗留的脚本和技能：清掉（旧文件已在上面的 .upgrade-backup 里；旧数据 inbox 等原样保留，kb search 仍能查）
for f in $RETIRED_SCRIPTS; do rm -f "$KB/$f"; done
for d in $RETIRED_SKILLS; do rm -rf "$HOME/.claude/skills/$d"; done
cp "$HERE/VERSION" "$KB/.knowledge-kit"
[ -e "$KB/.gitignore" ] || cp "$HERE/templates/knowledge.gitignore" "$KB/.gitignore"

# 配置：记录知识库位置
mkdir -p "$CONF_DIR"
python3 - "$KB" "$HERE/VERSION" "$CONF" <<'PYEOF'
import json, sys
from pathlib import Path
kb, ver, conf = sys.argv[1], Path(sys.argv[2]).read_text().strip(), sys.argv[3]
try:
    cfg = json.loads(Path(conf).read_text())   # 保留用户手改过的其它项（如 threshold）
    cfg = cfg if isinstance(cfg, dict) else {}
except Exception:
    cfg = {}
cfg.update({"kb_home": kb, "version": ver})
Path(conf).write_text(json.dumps(cfg, ensure_ascii=False, indent=1))
PYEOF

# 技能：把 {{KB}} 替换成实际路径（含空格时自动加引号，保证命令可直接执行）
mkdir -p "$HOME/.claude/skills"
python3 - "$KB" "$HERE/skills" "$HOME/.claude/skills" <<'PYEOF'
import shlex, sys
from pathlib import Path
kb, src, dst = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
q = shlex.quote(kb)
for d in sorted(src.iterdir()):
    if not d.is_dir():
        continue
    out = dst / d.name
    out.mkdir(parents=True, exist_ok=True)
    for f in d.iterdir():
        if f.is_file():
            (out / f.name).write_text(f.read_text(encoding="utf-8").replace("{{KB}}", q), encoding="utf-8")
PYEOF

# 全局 CLAUDE.md：没有才按模板创建，已有则不覆盖
mkdir -p "$HOME/.claude"
if [ -e "$HOME/.claude/CLAUDE.md" ]; then
  echo "已存在 ~/.claude/CLAUDE.md，未覆盖。模板在 $HERE/templates/CLAUDE.global.md，请手动合并。"
else
  python3 - "$KB" "$HERE/templates/CLAUDE.global.md" "$HOME/.claude/CLAUDE.md" <<'PYEOF'
import sys
from pathlib import Path
kb, src, dst = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
dst.write_text(src.read_text(encoding="utf-8").replace("{{KB}}", kb), encoding="utf-8")
PYEOF
  echo "已创建 ~/.claude/CLAUDE.md"
fi

echo "已安装到 $KB"
echo "已安装技能: $(for sd in "$HERE"/skills/*/; do printf '/%s ' "$(basename "$sd")"; done)（需要重启 Claude Code，或在 IDE 里重开会话后生效）"
if [ -d "$KB/inbox" ]; then
  echo "提示：$KB/inbox 等是旧版本留下的数据，已保留；新版不再生成它们，kb search 仍能查到。旧版写进 ~/.claude/CLAUDE.md 的规则可让 Agent 运行 kb rules migrate 导入。"
fi
echo ""
echo "下一步:"
echo "  1. 重启 Claude Code，正常使用：它的 auto memory 会自己记笔记，不需要你做任何事"
echo "  2. 想先看看效果，对 Claude 说「演示一下知识库」（用模拟数据，不碰真实数据）"
echo "  3. 用 Claude 桌面版的话，对 Claude Code 说「把知识库接入 Claude 桌面版」（会改桌面版的配置，需要你同意并完全重启桌面版）"
echo "  4. 过几天对 Claude 说「今天该做什么」"
echo "  Agent 自查: python3 \"$KB/kb.py\" doctor    自检: python3 \"$HERE/selftest.py\""
