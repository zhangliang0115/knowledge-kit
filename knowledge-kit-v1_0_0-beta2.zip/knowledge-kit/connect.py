#!/usr/bin/env python3
"""接入 Claude 桌面版：把本地 MCP 服务登记进 claude_desktop_config.json。
只改我们自己那一项（knowledge-kit），改之前先备份；配置文件不是合法 JSON 时拒绝改动。

python3 connect.py status                 看有没有接入、路径是否还有效
python3 connect.py desktop [--dry-run]    登记（需要用户同意；之后必须完全退出并重开桌面版才生效）
python3 connect.py remove [--quiet]       移除我们那一项
python3 connect.py instructions           打印要贴进桌面版"个人偏好"的那段话

Claude Code 命令行不需要接入：它的技能可以直接调用 kb 命令。
"""
import json, shutil, sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from kbcommon import kb_home, atomic_write

NAME = "knowledge-kit"
INSTRUCTIONS = """我有一个个人知识库，通过 knowledge-kit 提供工具。请这样用：
1. 每次新对话开始时，先调用 kb_rules 读取我的个人规则，并遵守它们。
2. 遇到可能以前碰过的问题，先用 kb_search 在我所有项目的记忆里查一下。
3. 当我明确说“记一下”，或做出重要决定时，用 kb_note_add 记下来（feedback=纠正或偏好，project=决策或事实，reference=资料位置）。内容里不要包含密钥或口令。
4. 不要自己把任何东西写成“规则”：固化规则只能在 Claude Code 里由我逐条确认。"""


class ConfigError(Exception):
    pass


def desktop_dir():
    return Path.home() / "Library" / "Application Support" / "Claude"


def config_path():
    return desktop_dir() / "claude_desktop_config.json"


def desktop_installed():
    return desktop_dir().is_dir()


def load_config():
    p = config_path()
    if not p.exists():
        return {}
    try:
        cfg = json.loads(p.read_text())
    except ValueError:
        raise ConfigError(f"{p} 不是合法的 JSON（可能有多余的逗号），为避免弄坏它，我没有改动。请先修好或让用户确认后重建。")
    if not isinstance(cfg, dict) or not isinstance(cfg.get("mcpServers", {}), dict):
        raise ConfigError(f"{p} 的结构不是预期的（顶层应是对象，mcpServers 也应是对象），我没有改动。")
    return cfg


def entry():
    script = kb_home() / "mcp_server.py"
    if not script.exists():
        raise ConfigError(f"找不到 {script}。请先运行 install.sh 安装。")
    # 桌面版从图形界面启动，没有 shell 的 PATH，所以必须写 python 的绝对路径；也不要用相对路径
    return {"command": sys.executable, "args": [str(script)]}


def desktop_connected():
    try:
        return NAME in load_config().get("mcpServers", {})
    except ConfigError:
        return False


def _backup():
    p = config_path()
    if p.exists():
        b = p.with_name(p.name + f".bak-{datetime.now():%Y%m%d-%H%M%S}")
        shutil.copy2(p, b)
        return b
    return None


def _save(cfg):
    atomic_write(config_path(), json.dumps(cfg, ensure_ascii=False, indent=2) + "\n")


def connect(dry=False, force=False):
    want = entry()
    if not desktop_installed() and not force:
        raise ConfigError(f"没找到 Claude 桌面版（{desktop_dir()} 不存在）。如果它装在别处，请用户确认后加 --force。")
    cfg = load_config()
    if cfg.get("mcpServers", {}).get(NAME) == want:
        print("已经接入，配置没有变化。若桌面版里看不到工具，请完全退出（不是关窗口）再重新打开。")
        return
    if dry:
        print(f"[预演] 将在 {config_path()} 的 mcpServers 里写入：\n" + json.dumps({NAME: want}, ensure_ascii=False, indent=2))
        return
    b = _backup()
    cfg.setdefault("mcpServers", {})[NAME] = want
    _save(cfg)
    print(f"已写入 {config_path()}" + (f"（原文件备份为 {b.name}）" if b else "") + "\n"
          "下一步：请用户【完全退出】Claude 桌面版再重新打开（只关窗口不够）。\n"
          "然后把 kb connect instructions 打印的那段话贴进桌面版的个人偏好，桌面版里的 Claude 才会主动使用知识库。")


def remove(quiet=False):
    try:
        cfg = load_config()
    except ConfigError as e:
        if not quiet:
            print(e)
        return
    if NAME not in cfg.get("mcpServers", {}):
        if not quiet:
            print("没有接入，无需移除。")
        return
    b = _backup()
    del cfg["mcpServers"][NAME]
    _save(cfg)
    if not quiet:
        print(f"已从 {config_path()} 移除（备份 {b.name}）。请完全退出并重开桌面版。")


def status():
    print(f"Claude 桌面版：{'已安装' if desktop_installed() else '没找到'}（{desktop_dir()}）")
    try:
        cfg = load_config()
    except ConfigError as e:
        print(f"配置：有问题 → {e}")
        return
    e = cfg.get("mcpServers", {}).get(NAME)
    if not e:
        print("接入：没有。需要的话征得同意后运行 kb connect desktop")
        return
    cmd, args = e.get("command", ""), e.get("args", [])
    ok_cmd, ok_script = Path(cmd).exists(), bool(args) and Path(args[0]).exists()
    print(f"接入：已登记。python：{cmd}（{'存在' if ok_cmd else '不存在'}）；服务脚本：{args[0] if args else '?'}（{'存在' if ok_script else '不存在'}）")
    if not (ok_cmd and ok_script):
        print("路径已失效（知识库或 python 搬过家）：重新运行 kb connect desktop。")
    print("Claude Code 命令行不需要接入，它的技能直接调用 kb 命令。")


def main():
    a = sys.argv[1:]
    cmd = a[0] if a else "status"
    try:
        if cmd == "status":
            status()
        elif cmd == "desktop":
            connect("--dry-run" in a, "--force" in a)
        elif cmd == "remove":
            remove("--quiet" in a)
        elif cmd == "instructions":
            print(INSTRUCTIONS)
        else:
            print(__doc__)
            return 0 if cmd in ("-h", "--help", "help") else 2
    except ConfigError as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
