"""MCP 服务：用真实的 stdio 管道按协议通信（和桌面版启动它的方式一致）。"""
import json, subprocess, sys
from helpers import KBCase, KIT, install, make_env, seed_cross_project, write_memory


class McpCase(KBCase):
    def setUp(self):
        super().setUp()
        self.kb = self.home / "knowledge"; self.env = make_env(self.home)
        self.assertEqual(0, install(self.home, self.kb).returncode)
        self.proc = subprocess.Popen([sys.executable, str(self.kb / "mcp_server.py")], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, env=self.env)
        self._id = 0

    def tearDown(self):
        try:
            self.proc.stdin.close(); self.proc.wait(timeout=10)
        except Exception:
            self.proc.kill()
        for s in (self.proc.stdout, self.proc.stderr):
            s.close()

    def send(self, obj):
        self.proc.stdin.write((obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False)) + "\n"); self.proc.stdin.flush()

    def rpc(self, method, params=None):
        self._id += 1
        self.send({"jsonrpc": "2.0", "id": self._id, "method": method, "params": params or {}})
        line = self.proc.stdout.readline()
        self.assertTrue(line, "服务没有响应：" + self.proc.stderr.read() if self.proc.poll() is not None else "服务没有响应")
        msg = json.loads(line); self.assertEqual(self._id, msg["id"]); return msg

    def call(self, name, args=None):
        r = self.rpc("tools/call", {"name": name, "arguments": args or {}})["result"]
        return r["content"][0]["text"], r["isError"]


class ProtocolTest(McpCase):
    def test_initialize_echoes_supported_version_and_declares_tools_only(self):
        r = self.rpc("initialize", {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "t", "version": "1"}})["result"]
        self.assertEqual("2024-11-05", r["protocolVersion"]); self.assertEqual("knowledge-kit", r["serverInfo"]["name"])
        self.assertEqual(["tools"], list(r["capabilities"]))

    def test_unsupported_version_gets_a_known_one(self):
        self.assertEqual("2025-06-18", self.rpc("initialize", {"protocolVersion": "1999-01-01"})["result"]["protocolVersion"])

    def test_notifications_get_no_reply_and_ping_works(self):
        self.send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        self.send({"jsonrpc": "2.0", "method": "notifications/cancelled", "params": {"requestId": 9}})
        self.assertEqual({}, self.rpc("ping")["result"], "通知之后的第一条回复必须是 ping 的，说明通知没有产生回复")

    def test_unknown_method_and_malformed_input_do_not_kill_server(self):
        self.assertEqual(-32601, self.rpc("resources/list")["error"]["code"])
        self.send("{这不是 JSON"); self.assertEqual(-32700, json.loads(self.proc.stdout.readline())["error"]["code"])
        self.send(""); self.send("[1]"); self.assertEqual(-32600, json.loads(self.proc.stdout.readline())["error"]["code"])
        self.assertEqual({}, self.rpc("ping")["result"])

    def test_stdout_contains_only_protocol_messages(self):
        self.rpc("initialize", {"protocolVersion": "2025-06-18"}); self.rpc("tools/list"); self.call("kb_status"); self.call("kb_search", {"query": "x"})
        self.proc.stdin.close(); out = self.proc.stdout.read()
        for ln in filter(None, out.splitlines()): self.assertEqual("2.0", json.loads(ln)["jsonrpc"])
        self.assertEqual(0, self.proc.wait(timeout=10), "输入结束后应正常退出")

    def test_tools_list_is_well_formed_and_never_exposes_rule_writing(self):
        tools = self.rpc("tools/list")["result"]["tools"]
        names = [t["name"] for t in tools]
        self.assertEqual(sorted(["kb_rules", "kb_search", "kb_memories", "kb_candidates", "kb_status", "kb_note_add"]), sorted(names))
        for t in tools:
            self.assertEqual("object", t["inputSchema"]["type"]); self.assertTrue(t["description"])
        self.assertFalse([n for n in names if "rule" in n and n != "kb_rules"], "不能暴露写规则的工具")
        ro = {t["name"]: t["annotations"]["readOnlyHint"] for t in tools}
        self.assertEqual({"kb_note_add"}, {n for n, v in ro.items() if not v})

    def test_unknown_tool_is_protocol_error(self):
        self.assertEqual(-32602, self.rpc("tools/call", {"name": "kb_rules_add", "arguments": {}})["error"]["code"])


class ToolTest(McpCase):
    def test_status_and_rules(self):
        text, err = self.call("kb_status"); self.assertFalse(err); self.assertIn("next", json.loads(text))
        self.assertIn("还没有", self.call("kb_rules")[0])
        subprocess.run([sys.executable, str(self.kb / "kb.py"), "rules", "add", "提交信息用中文"], env=self.env, capture_output=True, stdin=subprocess.DEVNULL)
        self.assertIn("1. 提交信息用中文", self.call("kb_rules")[0])

    def test_search_memories_candidates_read_the_same_data_as_the_cli(self):
        seed_cross_project(self.home)
        self.assertIn("feedback_c.md", self.call("kb_search", {"query": "注释", "limit": 5})[0])
        text, err = self.call("kb_search", {"query": "提交信息", "project": "docs-site"}); self.assertFalse(err); self.assertIn("提交信息请用中文书写", text)
        self.assertIn("Lombok", self.call("kb_memories", {"type": "feedback", "limit": 50})[0])
        self.assertIn("主题词", self.call("kb_candidates")[0])

    def test_argument_injection_is_neutralised(self):
        text, err = self.call("kb_search", {"query": "--help"}); self.assertFalse(err)
        self.assertIn("没有找到", text); self.assertNotIn("usage", text.lower())
        write_memory(self.home, "-P", "feedback_x.md", "feedback", "- 以横线开头的描述也要能搜到")
        self.assertIn("以横线开头", self.call("kb_search", {"query": "横线"})[0])

    def test_note_add_creates_note_visible_to_cli_and_dedupes(self):
        text, err = self.call("kb_note_add", {"type": "feedback", "description": "写邮件先给结论", "project": "桌面版测试"})
        self.assertFalse(err); self.assertIn("已记录", text)
        self.assertEqual(1, len(list((self.kb / "notes").glob("*.md"))))
        self.assertIn("写邮件先给结论", subprocess.run([sys.executable, str(self.kb / "kb.py"), "memories", "-p", "桌面版测试"], env=self.env, capture_output=True, text=True, stdin=subprocess.DEVNULL).stdout)
        self.assertIn("已有相同", self.call("kb_note_add", {"type": "feedback", "description": "写邮件先给结论", "project": "桌面版测试"})[0])
        self.assertEqual(1, len(list((self.kb / "notes").glob("*.md"))))

    def test_note_description_starting_with_dash_works(self):
        text, err = self.call("kb_note_add", {"type": "project", "description": "- 用连字符开头的一句话描述"}); self.assertFalse(err, text)

    def test_note_rejections_report_isError_and_write_nothing(self):
        for args in ({"type": "闲聊", "description": "类型不合法的笔记"}, {"type": "feedback", "description": "abc"},
                     {"type": "feedback", "description": "连库时用 password=Zx81hunter2!!"}, {"type": "feedback", "description": "正常描述", "body": "x" * 2001},
                     {"type": "feedback"}, {"type": "feedback", "description": 123}):
            text, err = self.call("kb_note_add", args); self.assertTrue(err, args); self.assertNotIn("hunter2", text)
        self.assertFalse((self.kb / "notes").exists() and list((self.kb / "notes").glob("*.md")))

    def test_bad_argument_types(self):
        for name, args in (("kb_search", {}), ("kb_search", {"query": "  "}), ("kb_search", {"query": "a", "limit": "x"}), ("kb_memories", {"since_days": 0}),
                           ("kb_memories", {"type": "闲聊"})):
            self.assertTrue(self.call(name, args)[1], (name, args))
        r = self.rpc("tools/call", {"name": "kb_status", "arguments": "不是对象"})["result"]; self.assertTrue(r["isError"])

    def test_desktop_note_joins_cross_project_cluster(self):
        seed_cross_project(self.home)
        self.call("kb_note_add", {"type": "feedback", "description": "写代码时别加多余的注释"})
        cs = json.loads(subprocess.run([sys.executable, str(self.kb / "kb.py"), "candidates", "--json"], env=self.env, capture_output=True, text=True, stdin=subprocess.DEVNULL).stdout)
        c = next(c for c in cs if "注释" in c["topic"]); self.assertEqual(4, len(c["projects"])); self.assertIn("Claude 桌面版", c["projects"])
