from helpers import KBCase, install, make_env, run, settings, write_memory


class DoctorTest(KBCase):
    def setUp(self):
        super().setUp()
        self.kb = self.home / "knowledge"; self.env = make_env(self.home)
        self.assertEqual(0, install(self.home, self.kb).returncode)
        self.doctor = str(self.kb / "doctor.py")

    def d(self):
        return run(self.doctor, env=self.env)

    def test_fresh_install_has_no_failures(self):
        r = self.d(); self.assertEqual(0, r.returncode, r.stdout); self.assertNotIn("✘", r.stdout); self.assertIn("3 个技能已安装", r.stdout)

    def test_missing_skill_script_and_stale_path_fail(self):
        (self.home / ".claude" / "skills" / "kb-quiz" / "SKILL.md").unlink()
        r = self.d(); self.assertEqual(1, r.returncode); self.assertIn("kb-quiz", r.stdout)

    def test_stale_skill_path(self):
        f = self.home / ".claude" / "skills" / "kb-ops" / "SKILL.md"; f.write_text(f.read_text().replace(str(self.kb), "/somewhere/else"))
        r = self.d(); self.assertEqual(1, r.returncode); self.assertIn("路径", r.stdout)

    def test_leftovers_from_old_versions_only_warn(self):
        (self.kb / "promote.py").write_text("old"); (self.home / ".claude" / "skills" / "kb-daily").mkdir()
        r = self.d(); self.assertEqual(0, r.returncode); self.assertIn("⚠ 没有旧版遗留脚本", r.stdout); self.assertIn("⚠ 没有旧版遗留技能", r.stdout)

    def test_memory_off_warns_not_fails(self):
        settings(self.home, autoMemoryEnabled=False)
        r = self.d(); self.assertEqual(0, r.returncode); self.assertIn("⚠ 官方 auto memory 已开启", r.stdout); self.assertIn("/memory", r.stdout)

    def test_corrupt_state_file_fails(self):
        (self.kb / "review" / "state.json").write_text("{坏")
        self.assertEqual(1, self.d().returncode)

    def test_finds_official_memory(self):
        write_memory(self.home, "-P", "feedback_x.md", "feedback", "提交信息用中文")
        self.assertIn("✔ 找到官方记忆目录", self.d().stdout)
