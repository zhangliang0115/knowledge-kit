import os, re, subprocess, sys
from helpers import KBCase, KIT


class SkillTest(KBCase):
    def test_skill_names_match_dirs_and_code_list(self):
        sys.path.insert(0, str(KIT)); from kbcommon import SKILLS
        self.assertEqual(sorted(SKILLS), sorted(p.name for p in (KIT / "skills").iterdir() if p.is_dir()), "kbcommon.SKILLS 必须和 skills/ 目录一致")
        for d in SKILLS:
            md = (KIT / "skills" / d / "SKILL.md").read_text()
            self.assertTrue(md.startswith(f"---\nname: {d}\n"), d)
            self.assertRegex(md.split("---")[1], r"description: .{30,}", d)
            self.assertIn("不要在用户没提出时自行运行" if d != "kb-ops" else "用户不会自己敲命令", md)

    def test_every_kb_command_used_in_skills_exists(self):
        cmds = set()
        for p in (KIT / "skills").glob("*/SKILL.md"):
            cmds |= set(re.findall(r"kb\.py (?:--json|([a-z]+))", p.read_text()))
        cmds.discard("")
        self.assertTrue({"search", "memories", "rules", "audit", "candidates", "quiz"} <= cmds)
        for c in sorted(cmds):
            r = subprocess.run([sys.executable, str(KIT / "kb.py"), c, "--help"], capture_output=True, text=True, stdin=subprocess.DEVNULL,
                               env=dict(os.environ, KB_HOME=str(self.kb), HOME=str(self.home)), timeout=60)
            self.assertNotEqual(2, r.returncode, f"技能里用到的 kb.py {c} 不存在：{r.stdout[:80]}")

    def test_skills_state_the_safety_boundaries(self):
        promote = (KIT / "skills" / "kb-promote" / "SKILL.md").read_text()
        for must in ("逐条问用户", "不要自己加 `--force`", "hook", "不要自己改任何 CLAUDE.md"):
            self.assertIn(must, promote)
        self.assertIn("记笔记不需要用我们的命令", (KIT / "skills" / "kb-ops" / "SKILL.md").read_text())


class DocsTest(KBCase):
    def docs(self):
        return [KIT / "README.md", KIT / "AGENT_INSTALL.md", KIT / "TODO.md", *sorted((KIT / "docs").glob("*.md"))]

    def test_versions_agree(self):
        ver = (KIT / "VERSION").read_text().strip()
        self.assertTrue((KIT / "README.md").read_text().startswith(f"# knowledge-kit v{ver}"))
        self.assertTrue((KIT / "CHANGELOG.md").read_text().split("## ", 2)[1].startswith(ver))
        self.assertIn(f"v{ver}", (KIT / "AGENT_INSTALL.md").read_text().splitlines()[0])

    def test_readme_lists_all_docs(self):
        readme = (KIT / "README.md").read_text()
        for d in (KIT / "docs").glob("*.md"): self.assertIn(f"docs/{d.name}", readme, d.name)

    def test_references_exist(self):
        for d in self.docs():
            txt = d.read_text()
            for ref in set(re.findall(r"(?<![/\w.~])(?:docs/[\w\-]+\.md|templates/[\w.\-]+|skills/[\w\-]+|tests/[\w.\-]+)", txt)):
                self.assertTrue((KIT / ref).exists(), f"{d.name} 引用了不存在的 {ref}")
            for sc in set(re.findall(r"(?<![/\w])([A-Za-z_]+)\.py\b", txt)):  # 带目录前缀的（如 tests/xxx.py）不算顶层脚本
                if sc in ("promote", "extract", "distill") and d.name in ("CHANGELOG.md", "TODO.md", "architecture.md", "roadmap.md"):
                    continue  # 这些文档会讲已移除的旧脚本
                self.assertTrue((KIT / f"{sc}.py").exists(), f"{d.name} 引用了不存在的脚本 {sc}.py")

    def test_installer_ships_and_uninstaller_cleans_every_script(self):
        inst, un = (KIT / "install.sh").read_text(), (KIT / "uninstall.sh").read_text()
        for f in KIT.glob("*.py"):
            if f.name == "selftest.py": continue
            self.assertIn(f.name, inst, f"install.sh 没有安装 {f.name}"); self.assertIn(f.name, un, f"uninstall.sh 没有清理 {f.name}")

    def test_doctor_script_list_matches_files(self):
        txt = (KIT / "doctor.py").read_text()
        listed = set(re.findall(r'"(\w+\.py)"', re.search(r"SCRIPTS = \[(.*?)\]", txt).group(1)))
        shipped = {f.name for f in KIT.glob("*.py")} - {"selftest.py", "demo.py"}
        self.assertEqual(shipped, listed)
