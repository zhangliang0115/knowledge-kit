import json, sys
from pathlib import Path
from helpers import KBCase, install, make_env, run


class ConnectTest(KBCase):
    def setUp(self):
        super().setUp()
        self.kb = self.home / "knowledge"; self.env = make_env(self.home)
        self.assertEqual(0, install(self.home, self.kb).returncode)
        self.app = self.home / "Library" / "Application Support" / "Claude"
        self.cfg = self.app / "claude_desktop_config.json"

    def c(self, *a):
        return run(self.kb / "connect.py", *a, env=self.env)

    def entry(self):
        return json.loads(self.cfg.read_text())["mcpServers"]["knowledge-kit"]

    def test_not_installed_refuses_unless_forced(self):
        r = self.c("desktop"); self.assertNotEqual(0, r.returncode); self.assertIn("没找到", r.stderr); self.assertFalse(self.cfg.exists())
        self.assertEqual(0, self.c("desktop", "--force").returncode); self.assertTrue(self.cfg.exists())

    def test_writes_absolute_paths_and_preserves_other_servers_and_keys(self):
        self.app.mkdir(parents=True)
        self.cfg.write_text(json.dumps({"theme": "dark", "mcpServers": {"other": {"command": "npx", "args": ["x"]}}}))
        r = self.c("desktop"); self.assertEqual(0, r.returncode, r.stderr); self.assertIn("完全退出", r.stdout)
        data = json.loads(self.cfg.read_text())
        self.assertEqual("dark", data["theme"]); self.assertEqual({"command": "npx", "args": ["x"]}, data["mcpServers"]["other"])
        e = data["mcpServers"]["knowledge-kit"]
        self.assertTrue(Path(e["command"]).is_absolute() and Path(e["command"]).exists())
        self.assertEqual([str(self.kb / "mcp_server.py")], e["args"]); self.assertNotIn("env", e)
        self.assertEqual(1, len(list(self.app.glob("claude_desktop_config.json.bak-*"))), "改之前必须备份")

    def test_idempotent_no_second_backup_and_dry_run_changes_nothing(self):
        self.app.mkdir(parents=True); self.cfg.write_text("{}")
        self.assertIn("预演", self.c("desktop", "--dry-run").stdout); self.assertEqual("{}", self.cfg.read_text())
        self.c("desktop"); self.assertIn("已经接入", self.c("desktop").stdout)
        self.assertEqual(1, len(list(self.app.glob("*.bak-*"))))

    def test_invalid_json_is_never_overwritten(self):
        self.app.mkdir(parents=True); self.cfg.write_text('{"mcpServers": {"a": {},}}')
        r = self.c("desktop"); self.assertNotEqual(0, r.returncode); self.assertIn("没有改动", r.stderr)
        self.assertEqual('{"mcpServers": {"a": {},}}', self.cfg.read_text())
        self.assertEqual(0, self.c("remove", "--quiet").returncode)
        self.assertEqual('{"mcpServers": {"a": {},}}', self.cfg.read_text())

    def test_wrong_structure_is_rejected(self):
        self.app.mkdir(parents=True); self.cfg.write_text('{"mcpServers": []}')
        self.assertNotEqual(0, self.c("desktop").returncode); self.assertEqual('{"mcpServers": []}', self.cfg.read_text())

    def test_remove_only_touches_our_entry(self):
        self.app.mkdir(parents=True); self.cfg.write_text(json.dumps({"mcpServers": {"other": {"command": "x"}}}))
        self.c("desktop"); self.assertEqual(0, self.c("remove").returncode)
        self.assertEqual({"other": {"command": "x"}}, json.loads(self.cfg.read_text())["mcpServers"])
        self.assertIn("无需移除", self.c("remove").stdout)

    def test_status_reports_stale_paths(self):
        self.app.mkdir(parents=True); self.c("desktop")
        self.assertIn("已登记", self.c("status").stdout); self.assertNotIn("失效", self.c("status").stdout)
        data = json.loads(self.cfg.read_text()); data["mcpServers"]["knowledge-kit"]["args"] = ["/不存在/mcp_server.py"]; self.cfg.write_text(json.dumps(data))
        self.assertIn("路径已失效", self.c("status").stdout)

    def test_instructions_tell_desktop_not_to_write_rules(self):
        t = self.c("instructions").stdout
        for must in ("kb_rules", "kb_search", "kb_note_add", "不要自己把任何东西写成“规则”"): self.assertIn(must, t)

    def test_doctor_and_audit_notice_desktop_state(self):
        self.app.mkdir(parents=True)
        self.assertIn("⚠ 已接入 Claude 桌面版", run(self.kb / "doctor.py", env=self.env).stdout)
        self.assertIn("desktop_not_connected", run(self.kb / "kb.py", "audit", "--json", env=self.env).stdout)
        self.c("desktop")
        self.assertIn("✔ Claude 桌面版的接入路径有效", run(self.kb / "doctor.py", env=self.env).stdout)
        self.assertNotIn("desktop_not_connected", run(self.kb / "kb.py", "audit", "--json", env=self.env).stdout)

    def test_uninstall_removes_our_desktop_entry_but_not_others(self):
        from helpers import sh, KIT
        self.app.mkdir(parents=True); self.cfg.write_text(json.dumps({"mcpServers": {"other": {"command": "x"}}}))
        self.c("desktop"); self.assertEqual(0, sh(KIT / "uninstall.sh", "--yes", env=self.env).returncode)
        self.assertEqual({"other": {"command": "x"}}, json.loads(self.cfg.read_text())["mcpServers"])
        self.assertFalse((self.kb / "mcp_server.py").exists())
