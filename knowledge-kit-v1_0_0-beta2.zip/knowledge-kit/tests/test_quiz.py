from datetime import date, timedelta
from helpers import KBCase, jload


class QuizTest(KBCase):
    def setUp(self):
        super().setUp(); self.state = self.kb / "review" / "state.json"

    def q(self, *a):
        return self.script("quiz.py", *a)

    def add(self, text="为什么本地缓存选 Caffeine 不选 Redis？", *extra):
        r = self.q("add", text, *extra); self.assertEqual(0, r.returncode, r.stderr)
        return r.stdout.strip().split("：")[1]

    def test_add_is_idempotent_and_listed_today(self):
        qid = self.add(); self.assertIn("已存在", self.q("add", "为什么本地缓存选 Caffeine 不选 Redis？").stdout)
        self.assertEqual(1, len(jload(self.state))); self.assertIn(qid, self.q("today").stdout)

    def test_ctx_and_src_saved(self):
        qid = self.add("为什么订单表按月分表？", "--ctx", "历史数据归档到冷库", "--src", "order/project_sharding.md")
        it = jload(self.state)[qid]; self.assertEqual(("历史数据归档到冷库", "order/project_sharding.md"), (it["ctx"], it["src"]))

    def test_rejects_short_and_secret(self):
        self.assertNotEqual(0, self.q("add", "abc").returncode)
        r = self.q("add", "连接库的密码是什么呢", "--ctx", "password=Zx81hunter2!!")
        self.assertNotEqual(0, r.returncode); self.assertNotIn("hunter2", r.stdout + r.stderr); self.assertFalse(self.state.exists())

    def test_intervals_reset_and_history(self):
        qid = self.add()
        self.q("grade", qid, "g"); self.assertEqual(str(date.today() + timedelta(days=1)), jload(self.state)[qid]["due"])
        self.q("grade", qid, "g"); self.assertEqual(str(date.today() + timedelta(days=3)), jload(self.state)[qid]["due"])
        self.q("grade", qid, "f"); it = jload(self.state)[qid]
        self.assertEqual(0, it["box"]); self.assertEqual(["g", "g", "f"], [h[1] for h in it["hist"]])
        self.assertNotIn(qid, self.q("today").stdout, "评分后不再到期")

    def test_grade_errors_are_friendly(self):
        qid = self.add()
        for args in (("zzzzzz", "g"), (qid, "x"), (qid,)):
            r = self.q("grade", *args); self.assertNotEqual(0, r.returncode); self.assertNotIn("Traceback", r.stderr)

    def test_old_state_files_still_work(self):
        self.state.parent.mkdir(exist_ok=True)
        self.state.write_text('{"abc123": {"q": "旧版本留下的题目", "src": "2026-01-01", "ctx": "", "box": 2, "due": "2020-01-01", "n": 2}}')
        self.assertIn("abc123", self.q("today").stdout); self.assertEqual(0, self.q("grade", "abc123", "g").returncode)

    def test_interactive_session_exits_cleanly_without_terminal(self):
        self.add(); r = self.q(); self.assertEqual(0, r.returncode, r.stderr)
