import re, shlex, subprocess
from pathlib import Path
from helpers import KBCase, KIT, install, make_env, run, sh, jload


class InstallTest(KBCase):
    def setUp(self):
        super().setUp(); self.env = make_env(self.home)

    def test_custom_path_with_spaces_and_skill_substitution(self):
        kb = self.home / "My Notes" / "ai kb"
        r = install(self.home, kb); self.assertEqual(0, r.returncode, r.stdout + r.stderr)
        self.assertEqual(str(kb), jload(self.home / ".config" / "knowledge-kit" / "config.json")["kb_home"])
        for name in ("kb-ops", "kb-promote", "kb-quiz"):
            txt = (self.home / ".claude" / "skills" / name / "SKILL.md").read_text()
            self.assertNotIn("{{KB}}", txt); self.assertIn(shlex.quote(str(kb)), txt, name)
        for d in ("rules", "review", "work"):
            self.assertTrue((kb / d).is_dir(), d)
        for old in ("inbox", "decisions", "pitfalls"):
            self.assertFalse((kb / old).exists(), f"新安装不应再创建 {old}/")

    def test_installed_kb_works_end_to_end(self):
        kb = self.home / "My Notes" / "ai kb"; install(self.home, kb)
        k = lambda *a: run(kb / "kb.py", *a, env=self.env)
        r = k(); self.assertEqual(0, r.returncode, r.stderr); self.assertIn("还没有内容", r.stdout)
        self.assertEqual(0, k("audit").returncode); self.assertEqual(0, k("doctor").returncode)
        self.assertEqual(0, k("rules", "add", "提交信息用中文").returncode)
        self.assertEqual(0, k("demo").returncode)
        self.assertIn("提交信息用中文", (self.home / ".claude" / "rules" / "kb-promoted.md").read_text())

    def test_skill_commands_with_spaces_execute(self):
        kb = self.home / "My Notes" / "ai kb"; install(self.home, kb)
        cmd = "python3 " + shlex.quote(str(kb)) + "/kb.py --json"
        self.assertEqual(0, subprocess.run(["bash", "-c", cmd], env=self.env, capture_output=True, text=True).returncode)

    def test_existing_directory_needs_confirmation_and_is_not_modified(self):
        vault = self.home / "vault"; vault.mkdir(); (vault / "我的笔记.md").write_text("x")
        self.assertNotEqual(0, install(self.home, vault).returncode)
        self.assertEqual(0, install(self.home, vault, "--allow-existing").returncode)
        self.assertEqual("x", (vault / "我的笔记.md").read_text())

    def test_existing_global_claude_md_not_overwritten_and_template_mentions_skills(self):
        (self.home / ".claude").mkdir(exist_ok=True); (self.home / ".claude" / "CLAUDE.md").write_text("我自己的规则\n")
        install(self.home, self.home / "k")
        self.assertEqual("我自己的规则\n", (self.home / ".claude" / "CLAUDE.md").read_text())
        tpl = (KIT / "templates" / "CLAUDE.global.md").read_text()
        for s in ("/kb-ops", "/kb-promote", "/kb-quiz"): self.assertIn(s, tpl)

    def test_fresh_claude_md_created_from_template(self):
        install(self.home, self.home / "k")
        self.assertIn("/kb-promote", (self.home / ".claude" / "CLAUDE.md").read_text())

    def test_noninteractive_install_does_not_touch_shell_rc_or_rules_file(self):
        install(self.home, self.home / "k")
        self.assertFalse((self.home / ".zshrc").exists() or (self.home / ".bash_profile").exists())
        self.assertFalse((self.home / ".claude" / "rules").exists(), "安装本身不应创建个人规则文件")

    def test_user_config_keys_survive_reinstall(self):
        cd = self.home / ".config" / "knowledge-kit"; cd.mkdir(parents=True)
        (cd / "config.json").write_text('{"similarity": 35, "kb_home": "/old"}')
        install(self.home, self.home / "newkb")
        c = jload(cd / "config.json"); self.assertEqual(35, c["similarity"]); self.assertEqual(str(self.home / "newkb"), c["kb_home"])

    def test_config_is_honoured_and_bad_values_ignored(self):
        import sys; sys.path.insert(0, str(KIT)); import os
        cd = self.home / ".config" / "knowledge-kit"; cd.mkdir(parents=True)
        old = os.environ.get("HOME"); os.environ["HOME"] = str(self.home)
        try:
            import kbcommon
            (cd / "config.json").write_text('{"similarity": 40, "min_projects": "x", "stale_days": -3, "topic_projects": true}')
            c = kbcommon.config()
            self.assertEqual(40, c["similarity"]); self.assertEqual(2, c["min_projects"]); self.assertEqual(180, c["stale_days"]); self.assertEqual(3, c["topic_projects"])
        finally:
            os.environ["HOME"] = old


class UpgradeUninstallTest(KBCase):
    def setUp(self):
        super().setUp(); self.env = make_env(self.home); self.k = self.home / "kb5"

    def uninstall(self, *a):
        return sh(KIT / "uninstall.sh", *a, env=self.env)

    def make_old_install(self):
        install(self.home, self.k)
        for f in ("distill.py", "promote.py", "extract.py"): (self.k / f).write_text("old " + f)
        for d in ("kb-daily", "kb-distill"):
            (self.home / ".claude" / "skills" / d).mkdir(); (self.home / ".claude" / "skills" / d / "SKILL.md").write_text("old " + d)
        (self.k / "inbox").mkdir(); (self.k / "inbox" / "2026-01-01.md").write_text("- [纠正] a | b | c\n")
        (self.k / "review" / "state.json").write_text('{"abc123": {"q": "旧题目", "src": "", "ctx": "", "box": 1, "due": "2020-01-01", "n": 1}}')

    def test_first_install_has_no_backup_second_does(self):
        install(self.home, self.k); self.assertFalse((self.k / ".upgrade-backup").exists())
        install(self.home, self.k)
        self.assertTrue(list((self.k / ".upgrade-backup").glob("*/kb.py")))
        self.assertTrue(list((self.k / ".upgrade-backup").glob("*/skills/kb-quiz/SKILL.md")))

    def test_upgrade_removes_retired_pieces_backs_them_up_and_keeps_data(self):
        self.make_old_install(); self.assertEqual(0, install(self.home, self.k).returncode)
        for f in ("distill.py", "promote.py", "extract.py"): self.assertFalse((self.k / f).exists(), f)
        for d in ("kb-daily", "kb-distill"): self.assertFalse((self.home / ".claude" / "skills" / d).exists(), d)
        bk = next((self.k / ".upgrade-backup").iterdir())
        self.assertEqual("old promote.py", (bk / "promote.py").read_text()); self.assertEqual("old kb-daily", (bk / "skills" / "kb-daily" / "SKILL.md").read_text())
        self.assertEqual("- [纠正] a | b | c\n", (self.k / "inbox" / "2026-01-01.md").read_text())
        self.assertIn("旧题目", (self.k / "review" / "state.json").read_text())
        self.assertIn("kb search", install(self.home, self.k).stdout)
        r = run(self.k / "doctor.py", env=self.env); self.assertEqual(0, r.returncode, r.stdout)

    def test_old_quiz_state_keeps_working_after_upgrade(self):
        self.make_old_install(); install(self.home, self.k)
        self.assertIn("abc123", run(self.k / "quiz.py", "today", env=self.env).stdout)

    def test_retired_lists_match_between_installer_and_code(self):
        import sys; sys.path.insert(0, str(KIT)); import kbcommon
        txt = (KIT / "install.sh").read_text()
        skills = re.search(r'RETIRED_SKILLS="([^"]*)"', txt).group(1).split()
        scripts = re.search(r'RETIRED_SCRIPTS="([^"]*)"', txt).group(1).split()
        self.assertEqual(sorted(kbcommon.RETIRED_SKILLS), sorted(skills)); self.assertEqual(sorted(kbcommon.RETIRED_SCRIPTS), sorted(scripts))
        un = (KIT / "uninstall.sh").read_text()
        for n in skills + scripts: self.assertIn(n, un, f"uninstall.sh 没有清理旧版 {n}")

    def test_uninstall_requires_confirmation(self):
        install(self.home, self.k); self.assertNotEqual(0, self.uninstall().returncode); self.assertTrue((self.k / "kb.py").exists())

    def test_uninstall_removes_tool_keeps_data_and_personal_rules(self):
        self.make_old_install()
        run(self.k / "kb.py", "rules", "add", "提交信息用中文", env=self.env)
        r = self.uninstall("--yes"); self.assertEqual(0, r.returncode, r.stdout + r.stderr)
        self.assertFalse(any((self.k / f).exists() for f in ("kb.py", "official.py", "demo.py", "distill.py", ".knowledge-kit")))
        for d in ("kb-ops", "kb-promote", "kb-quiz", "kb-daily", "kb-distill"):
            self.assertFalse((self.home / ".claude" / "skills" / d).exists(), d)
        self.assertFalse((self.home / ".config" / "knowledge-kit").exists())
        self.assertEqual("- [纠正] a | b | c\n", (self.k / "inbox" / "2026-01-01.md").read_text())
        self.assertIn("提交信息用中文", (self.home / ".claude" / "rules" / "kb-promoted.md").read_text(), "确认过的个人规则不能被卸载删掉")
        self.assertTrue((self.k / "rules" / "promoted-log.jsonl").exists())

    def test_uninstall_does_not_touch_unmarked_directory(self):
        d = self.k; d.mkdir(); (d / "doctor.py").write_text("mine")
        self.assertEqual(0, self.uninstall("--yes").returncode); self.assertEqual("mine", (d / "doctor.py").read_text())

    def test_no_scheduling_or_retired_features_shipped(self):
        for rel in ("distill.py", "promote.py", "extract.py", "templates/crontab.example"):
            self.assertFalse((KIT / rel).exists(), rel)
        for cmd in ("remind", "distill", "add", "keys"):
            self.assertEqual(2, run("kb.py", cmd, env=self.env).returncode, f"kb {cmd} 应已移除")
