"""测试公共工具：临时 HOME / 知识库、子进程调用脚本。只用标准库。"""
import json, os, subprocess, sys, tempfile, unittest
from datetime import date, timedelta
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent


def tmpdir():
    return Path(tempfile.mkdtemp())


def make_env(home=None, kb=None):
    """干净环境：HOME 指向临时目录；kb 给了就用 KB_HOME 指过去，否则去掉 KB_HOME。"""
    env = dict(os.environ)
    if home is not None:
        env["HOME"] = str(home)
    env.pop("KB_HOME", None)
    if kb is not None:
        env["KB_HOME"] = str(kb)
    return env


def run(script, *args, env=None, **kw):
    path = script if os.path.isabs(str(script)) else str(KIT / script)
    kw.setdefault("stdin", subprocess.DEVNULL)  # 子进程不能等键盘输入，否则测试会挂住
    kw.setdefault("timeout", 120)
    return subprocess.run([sys.executable, path, *map(str, args)], env=env, capture_output=True, text=True, **kw)


def sh(*args, env=None):
    return subprocess.run(["bash", *map(str, args)], env=env, capture_output=True, text=True, stdin=subprocess.DEVNULL)


def write_memory(home, projdir, filename, type_, description, ago=0, name=None, body="", cwd=None,
                 frontmatter=True, modified=True, index=True):
    """在 HOME 下造一个官方 auto memory 文件（~/.claude/projects/<projdir>/memory/<filename>）。"""
    proj = Path(home) / ".claude" / "projects" / projdir
    mem = proj / "memory"
    mem.mkdir(parents=True, exist_ok=True)
    if cwd and not list(proj.glob("*.jsonl")):
        (proj / "s.jsonl").write_text(json.dumps({"type": "user", "cwd": cwd, "message": {"content": "hi"}}) + "\n")
    when = (date.today() - timedelta(days=ago)).isoformat() + "T10:00:00Z"
    if frontmatter:
        fm = f"---\nname: {name or filename[:-3]}\ndescription: {description}\n" + (f"type: {type_}\n" if type_ else "") + (f"modified: {when}\n" if modified else "") + "---\n"
    else:
        fm = ""
    f = mem / filename
    f.write_text(fm + (body or ("" if frontmatter else description)) + "\n")
    if index:
        with (mem / "MEMORY.md").open("a") as fh:
            fh.write(f"- [{filename}]({filename}) - {description}\n")
    return f


def seed_cross_project(home):
    """三个项目都纠正过"注释"，两个项目纠正过"提交信息"，一个项目有 Lombok，一个有无关的 UI 纠正。"""
    write_memory(home, "-U-order", "feedback_c.md", "feedback", "不要自动给代码加注释，除非我明确要求", 30, cwd="/U/order-service")
    write_memory(home, "-U-web", "feedback_c.md", "feedback", "别给代码自动加注释，我会自己写", 12, cwd="/U/web-admin")
    write_memory(home, "-U-data", "feedback_c.md", "feedback", "不要在脚本里添加多余的注释", 5, cwd="/U/data-scripts")
    write_memory(home, "-U-order", "feedback_m.md", "feedback", "提交信息用中文，格式：类型(范围): 摘要", 28)
    write_memory(home, "-U-docs", "feedback_m.md", "feedback", "提交信息请用中文书写", 7, cwd="/U/docs-site")
    write_memory(home, "-U-order", "feedback_l.md", "feedback", "不要用 Lombok，getter/setter 手写", 21)
    write_memory(home, "-U-web", "feedback_ui.md", "feedback", "表格和表单统一用公司组件库，不要自己手写样式", 9)


def install(home, kb, *extra):
    return sh(KIT / "install.sh", "--kb", kb, *extra, env=make_env(home))


def settings(home, **kw):
    d = Path(home) / ".claude"
    d.mkdir(parents=True, exist_ok=True)
    (d / "settings.json").write_text(json.dumps(kw))


class KBCase(unittest.TestCase):
    """每个用例有独立的临时 HOME 和知识库（KB_HOME 指向 self.kb）。"""

    def setUp(self):
        self.home = tmpdir()
        self.kb = self.home / "knowledge"
        self.kb.mkdir()
        (self.home / ".claude" / "projects").mkdir(parents=True)
        self.env = make_env(self.home, self.kb)

    def script(self, name, *args):
        return run(name, *args, env=self.env)

    def no_tmp_leftovers(self):
        self.assertEqual([], list(self.home.rglob("*.tmp")), "不应遗留 .tmp 文件")


def jload(p):
    return json.loads(Path(p).read_text())
