#!/usr/bin/env python3
"""间隔复习（莱特纳盒子）。题目由 Agent 根据官方记忆出好，用 add 加入；评分后自动排下次复习时间。

python3 quiz.py add "题目" [--ctx 背景] [--src 来源]   加入一道题（同样的题不会重复加入）
python3 quiz.py today                                  列出今日到期的题
python3 quiz.py grade ID g|h|f                         评分：g记得 h模糊 f忘了
python3 quiz.py                                        终端里交互复习（Agent 请在对话里出题，用 /kb-quiz）
知识库位置见 kbcommon.kb_home()（安装时选定；环境变量 KB_HOME 可临时覆盖）
"""
import argparse, hashlib, json, subprocess
from datetime import date, timedelta
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent))
from kbcommon import kb_home, atomic_write, scan_text

KB = kb_home()
STATE = KB / "review" / "state.json"
INTERVALS = [1, 3, 7, 14, 30]  # 连续"记得"时的复习间隔（天）


def load():
    try:
        return json.loads(STATE.read_text())
    except Exception:
        return {}


def save(s):
    atomic_write(STATE, json.dumps(s, ensure_ascii=False, indent=1))


def add(q, ctx="", src=""):
    q = " ".join(q.split())
    if len(q) < 4:
        raise SystemExit("题目太短")
    if scan_text(q + " " + ctx):
        raise SystemExit("拒绝加入：题目或背景里含疑似密钥")
    s, qid = load(), hashlib.md5(q.encode()).hexdigest()[:6]
    if qid in s:
        return qid, False
    s[qid] = {"q": q, "src": src, "ctx": ctx[:600], "box": 0, "due": date.today().isoformat(), "n": 0}
    save(s)
    return qid, True


def due():
    s, t = load(), date.today().isoformat()
    return [(k, v) for k, v in sorted(s.items(), key=lambda kv: kv[1]["due"]) if v["due"] <= t]


def grade(qid, g):
    s = load()
    it = s[qid]
    if g == "g":
        days = INTERVALS[min(it["box"], len(INTERVALS) - 1)]
        it["box"] += 1
    elif g == "h":
        days = 1
    else:
        days, it["box"] = 1, 0
    it["n"] += 1
    it.setdefault("hist", []).append([date.today().isoformat(), g])
    it["due"] = (date.today() + timedelta(days=days)).isoformat()
    save(s)
    return days


def reveal(it):
    p = f"请根据背景用中文简要回答（150字内）：{it['q']}\n背景：{it['ctx'] or '无'}"
    r = subprocess.run(["claude", "-p", p], capture_output=True, text=True)
    print(r.stdout.strip() if r.returncode == 0 else "调用 claude 失败，可直接在 Claude Code 里问。")


def session():
    items = due()
    if not items:
        print("今日无到期题。")
        return
    for i, (qid, it) in enumerate(items, 1):
        print(f"\n[{i}/{len(items)}] {it['q']}" + (f"  (来自 {it['src']})" if it.get("src") else ""))
        try:
            input("先自己想，想好按回车… ")
            while True:
                c = input("[r]参考答案  [g]记得  [h]模糊  [f]忘了  [s]跳过 > ").strip().lower()
                if c == "r":
                    reveal(it)
                elif c in ("g", "h", "f"):
                    print(f"下次复习：{grade(qid, c)} 天后")
                    break
                elif c == "s":
                    break
        except (EOFError, KeyboardInterrupt):
            print("\n已退出，进度已保存。")
            return
    print("\n今日复习完成。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", nargs="?", default="session", choices=["session", "add", "today", "grade"])
    ap.add_argument("args", nargs="*")
    ap.add_argument("--ctx", default="")
    ap.add_argument("--src", default="")
    a = ap.parse_args()
    if a.cmd == "add":
        if len(a.args) != 1:
            raise SystemExit('用法：quiz.py add "题目" [--ctx 背景] [--src 来源]')
        qid, new = add(a.args[0], a.ctx, a.src)
        print(f"{'已加入' if new else '已存在'}：{qid}")
    elif a.cmd == "today":
        for k, v in due():
            print(k, v["q"])
    elif a.cmd == "grade":
        if len(a.args) != 2 or a.args[1] not in ("g", "h", "f"):
            raise SystemExit("用法：quiz.py grade 题号 g|h|f")
        if a.args[0] not in load():
            raise SystemExit(f"找不到题号 {a.args[0]}（可先运行 quiz.py today 查看）")
        print(f"下次复习：{grade(a.args[0], a.args[1])} 天后")
    else:
        session()


if __name__ == "__main__":
    main()
