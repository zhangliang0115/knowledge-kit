#!/usr/bin/env python3
"""自检：运行 tests/ 下的全部用例（用临时目录和模拟数据，不动你的真实知识库和 CLAUDE.md）。

python3 selftest.py            全部用例，成功时输出 PASS
python3 selftest.py -k quiz    只跑名字含 quiz 的用例（参数原样传给 unittest）
只用标准库；装了 pytest 的话也可以直接 `pytest tests/`。
"""
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    tests = HERE / "tests"
    if not tests.is_dir():
        sys.exit("找不到 tests/ 目录（selftest.py 需要和 tests/ 放在一起）")
    sys.path.insert(0, str(tests))
    argv = ["unittest", "discover", "-s", str(tests), *sys.argv[1:]]
    prog = unittest.main(module=None, argv=argv, exit=False)
    if prog.result.wasSuccessful():
        print(f"PASS: {prog.result.testsRun} 个用例通过（官方记忆阅读 / 相似度与聚类 / 个人规则 / kb 命令 / 自检 / 复习 / 体检 / 安装升级卸载 / 技能 / 文档一致性）")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
