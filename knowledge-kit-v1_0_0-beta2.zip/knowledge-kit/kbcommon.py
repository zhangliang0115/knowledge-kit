"""各脚本共用：知识库路径、配置、原子写入、敏感信息扫描、规则安全检查。"""
import json, os, re, tempfile
from pathlib import Path


def kb_home():
    """知识库位置：环境变量 KB_HOME > 脚本所在目录（装好后的知识库里有 .knowledge-kit 标记）> 配置文件 > ~/knowledge。"""
    env = os.environ.get("KB_HOME")
    if env:
        return Path(env).expanduser()
    here = Path(__file__).resolve().parent
    if (here / ".knowledge-kit").exists():
        return here
    try:
        conf = json.loads((Path.home() / ".config" / "knowledge-kit" / "config.json").read_text())
        if conf.get("kb_home"):
            return Path(conf["kb_home"]).expanduser()
    except Exception:
        pass
    return Path.home() / "knowledge"


SKILLS = ["kb-ops", "kb-promote", "kb-quiz"]  # 安装进 ~/.claude/skills 的技能（与 skills/ 目录一致，测试会核对）
RETIRED_SKILLS = ["kb-daily", "kb-distill"]   # 1.0.0 起不再提供：升级时清理
RETIRED_SCRIPTS = ["distill.py", "promote.py", "extract.py"]
DEFAULTS = {"min_projects": 2,     # 同一条纠正出现在几个项目里，才算跨项目候选
            "similarity": 25,      # 两条记忆字面重合多少算"可能是同一件事"（0-100，越高越严格）；只是粗筛，最终由 Agent 判断
            "topic_projects": 3,   # 同一个主题词出现在几个项目里，就算跨项目信号（即使字面重合不高）
            "stale_days": 180}     # 多少天没更新的 feedback 记忆算可能过期


def config():
    """配置 = 默认值 + ~/.config/knowledge-kit/config.json 里的同名项（类型不对的忽略）。"""
    cfg = dict(DEFAULTS)
    try:
        user = json.loads((Path.home() / ".config" / "knowledge-kit" / "config.json").read_text())
    except Exception:
        user = {}
    for k in DEFAULTS:
        v = user.get(k) if isinstance(user, dict) else None
        if isinstance(v, int) and not isinstance(v, bool) and v >= 1:
            cfg[k] = v
    cfg["similarity"] = min(cfg["similarity"], 100)
    return cfg


def atomic_write(path, text):
    """先写临时文件再替换，避免中途中断留下半截文件。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


SECRET_PATTERNS = [
    ("API key (sk-)", r"\bsk-[A-Za-z0-9_\-]{20,}"),
    ("AWS access key", r"\bAKIA[0-9A-Z]{16}\b"),
    ("GitHub token", r"\bgh[pousr]_[A-Za-z0-9]{30,}"),
    ("Bearer token", r"(?i)\bbearer\s+[A-Za-z0-9._\-]{20,}"),
    ("私钥", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    ("密码/令牌赋值", r"(?i)\b(?:password|passwd|secret|token|api[_-]?key)\b\s*[:=]\s*['\"]?[^\s'\"]{8,}"),
    ("连接串里的密码", r"(?i)(?:jdbc:[a-z]+|mysql|postgres(?:ql)?|redis|mongodb)://[^\s:@/]+:[^\s@/]+@"),
]
_COMPILED = [(n, re.compile(p)) for n, p in SECRET_PATTERNS]


def mask(s):
    return s[:4] + "***" if len(s) > 4 else "***"


def scan_text(text):
    """返回 [(类型, 脱敏片段, 行号)]；片段只保留前 4 个字符。"""
    hits = []
    for i, line in enumerate(text.splitlines(), 1):
        for name, rx in _COMPILED:
            m = rx.search(line)
            if m:
                hits.append((name, mask(m.group(0)), i))
    return hits


RISKY = re.compile(r"https?://|curl |wget |sudo |rm -rf|chmod |eval\(|base64|ignore (?:all|previous)|忽略(?:之前|以上|所有)|"
                   r"system prompt|系统提示|api[_-]?key|token|password|密码", re.I)


def check_rule(text):
    """规则文件里的内容会在每个会话里被当作指令执行，写入前拦截可疑内容。返回问题描述，没问题返回空串。"""
    if len(text) > 200:
        return "规则超过 200 字，请先精简成一句话"
    m = RISKY.search(text)
    return f"规则里含可疑内容“{m.group(0)}”（链接、命令、密钥相关词，或像在改写指令）" if m else ""
