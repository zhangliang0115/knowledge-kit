# 故障排查

> 这份文档是给 Claude 照着做的：遇到问题，对它说"知识库出问题了，帮我排查"。第一步永远是 `python3 <KB>/kb.py doctor`（安装问题）和 `kb.py audit`（数据问题）。

## 1. 对 Claude 说"今天该做什么"，它说官方记忆里还没有内容
1. `kb.py audit`：看是否有 `memory_off`（被关闭）或 `no_memory`（有很多会话却没有记忆目录）。
2. 官方记忆被关了：**用户自己输入 `/memory` 打开**（内置命令，你无法代劳）。也要检查环境变量 `CLAUDE_CODE_DISABLE_AUTO_MEMORY` 和项目级设置。
3. 刚开始用属正常：Claude 认为值得记时才会写，通常用几天后才出现。
4. 用了自定义目录：看 `~/.claude/settings.json` 的 `autoMemoryDirectory`，`kb.py` 会读那里。
5. 都不是：运行 `kb.py report`，把脱敏报告给用户转给作者（可能是官方文件位置或格式变了）。

## 2. `kb candidates` 说"没有跨项目的重复纠正"
- 正常情况：同一件事要在 ≥2 个项目的 feedback 记忆里都出现才算。
- 字面粗筛对换了说法的做不到：运行 `kb.py memories -t feedback`，自己读一遍找意思相同的；也可以 `kb candidates --threshold 15` 放宽。
- 记忆没被识别成 feedback：`kb.py audit` 看有没有 `format` 警告；`kb.py report` 里"类型来源"一行能看到有多少靠文件名、多少无法识别。

## 3. 规则写进去了，新会话里好像没生效
1. 规则文件在 `~/.claude/rules/kb-promoted.md`，**新开的会话才加载**。
2. 让用户在新会话里输入 `/memory`，看这个文件有没有出现在加载列表里。
3. 没有：这个行为我们没在真机验证过（见 `TODO.md`），把情况用 `kb.py report` 反馈。
4. 加载了但仍不遵守：规则只是上下文不是强制。写得更具体、加正反例；必须强制的事改用 hook。

## 4. 自检发现对照
见 `kb-ops` 技能里的对照表：`memory_off`、`index_over`/`index_near`、`secret`、`rule_recurs`、`candidates`、`legacy_rules`、`stale`、`quiz_backlog`、`format`/`no_memory`。其中 `secret` 要打开文件删掉那一行，**不要把内容复述给用户**。

## 5. `kb rules add` 被拒绝
- "已拒绝写入…可疑内容"：规则里有链接、命令或密钥相关词。把原因讲给用户；用户核对过原文并同意，才可加 `--force`。
- "与第 N 条规则重复"：给用户看那条已有规则，建议合并；用户坚持才加 `--allow-similar`。
- "含疑似密钥"：去掉再写，`--force` 也不行。

## 6. 安装问题
- `/kb-` 看不到技能：重启 Claude Code；`kb.py doctor` 看"技能已安装"一项。
- 体检提示技能路径不一致：知识库位置变过，重新运行 `install.sh --kb <当前位置>`。
- 体检提示旧版遗留脚本或技能：重新运行 `install.sh`（旧文件已自动备份）。
- 想退回旧版本：`<KB>/.upgrade-backup/` 里有升级前的脚本和技能。

## 7. Claude 桌面版里看不到知识库的工具
1. `kb.py connect status`：确认已登记、路径有效。路径失效就重新 `kb.py connect desktop`。
2. **必须完全退出桌面版再打开**（菜单里退出，不是关窗口）。改配置后不重启不会生效。
3. 配置文件不是合法 JSON：`connect` 会拒绝改动并指出文件位置，让用户确认后再修。
4. 桌面版里找不到 python：配置里写的是绝对路径；若 python 被卸载或搬走，重新 `kb.py connect desktop`。macOS 自带的 `/usr/bin/python3` 在没装命令行开发工具时会弹安装提示。
5. 服务启动了但工具报错：在终端里手动测一下：`printf '{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n' | python3 <KB>/mcp_server.py`，应输出一行 JSON。能输出说明服务本身没问题，问题在桌面版一侧。桌面版的日志位置我没有核实，请用户在它的开发者设置里找。
6. 桌面版里的 Claude 不遵守规则：它不会自动加载规则文件，要确认个人偏好里贴了 `kb connect instructions` 的那段话。
7. 都不行：`kb.py report` 把脱敏报告和桌面版的版本号一起反馈。

## 8. 反馈问题
运行 `kb.py report`，把输出转给作者。它只含版本、数量、问题代码，不含任何记忆内容、规则内容和项目名。
