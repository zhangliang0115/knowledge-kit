# 操作手册

> **执行者是 Claude Code，不是你。** 你只需要对它说需求，文中的命令都是 Claude 去运行的。Claude Code 的内置斜杠命令（`/memory`、`/doctor prompt-audit`、`/init`、`/plugin`、`/hookify`）和"重启"只能由你输入，Claude 会把要输入的那一行直接给你。`<KB>` 指知识库目录（默认 `~/knowledge`）。

## 日常节奏
| 频率 | 你做 | Claude 做 |
|---|---|---|
| 平时 | 正常使用，纠正它时说清楚（"不要……""以后……"） | 官方 auto memory 自己记，不需要额外操作 |
| 每周或每两周 | 说"看看有哪些跨项目的纠正可以固化成规则" | `/kb-promote`：找候选、核对、起草，逐条请你确认 |
| 想起来时 | 说"以前有没有遇到过……" | `kb search` 搜所有项目 |
| 每月 | 说"自检一下知识库" | `kb audit`，处理发现的问题 |
| 想练习时 | 说"考考我" | `/kb-quiz` |
| 每季（官方功能） | 输入 `/doctor prompt-audit`（只能你输入） | 官方审计 CLAUDE.md 的过时和冲突 |

## 命令速查（供 Claude 执行）
`kb` = `python3 <KB>/kb.py`；`kb --help` 看全部。
| 场景 | 命令 |
|---|---|
| 今天该做什么 | `kb`；`kb --json`（含 `next.code`、`next.say`） |
| 看官方记忆 | `kb memories [-t user\|feedback\|project\|reference] [-p 项目] [--since 天数] [--json]` |
| 跨项目检索 | `kb search 词1 词2 [-t 类型] [-p 项目] [-n 条数]`（所有词都要出现；同时查 0.x 留下的旧笔记） |
| 跨项目候选 | `kb candidates [--json] [--all] [--threshold 0-100] [--types feedback,user]` |
| 个人规则 | `kb rules`；`kb rules add "规则" [--cluster ID] [--force] [--allow-similar]`；`kb rules remove N`；`kb rules migrate` |
| 自检 | `kb audit [--json]`；退出码 1 表示有错误 |
| 复习 | `kb quiz add "题目" --ctx 要点 --src 来源`；`kb quiz today`；`kb quiz grade 题号 g\|h\|f` |
| 体检安装 | `kb doctor` |
| 诊断报告 | `kb report`（脱敏：只有数量和问题代码，不含记忆内容和项目名） |
| 备份 | `kb backup`（不含 `work/` 和旧版备份；个人规则文件在知识库之外，另有提示） |
| 记笔记 | `kb note add 类型 "一句话" [--body 细节] [-p 来源]`（类型 feedback/project/user/reference；桌面版通过 MCP 调的就是它；含密钥会拒绝） |
| 接入桌面版 | `kb connect status`；`kb connect desktop [--dry-run]`；`kb connect remove`；`kb connect instructions`（见下面“Claude 桌面版”） |
| 演示 | `kb demo`（模拟数据，临时沙箱，`--keep` 保留沙箱） |

## Claude 桌面版
- **接入**：`kb connect desktop` 在 `~/Library/Application Support/Claude/claude_desktop_config.json` 的 `mcpServers` 里加一项 `knowledge-kit`（用 python 的**绝对路径**，因为桌面版从图形界面启动，没有 shell 的 PATH）。改之前自动备份为 `claude_desktop_config.json.bak-时间`；只改自己那一项，其它服务和设置原样保留；文件不是合法 JSON 就拒绝改动。**必须完全退出并重开桌面版才生效。**
- **桌面版里的工具**：`kb_rules`、`kb_search`、`kb_memories`、`kb_candidates`、`kb_status`（只读）和 `kb_note_add`（存笔记）。**没有写规则的工具**，这是刻意的。
- **个人偏好**：桌面版不会自动加载规则文件，`kb connect instructions` 打印的那段话要贴进它的个人偏好，让它每次新对话先调用 `kb_rules`。
- **笔记**：存在 `<KB>/notes/`，格式和官方记忆一致，带 `project: Claude 桌面版`（可自定义来源名）。`kb search`、`kb memories`、`kb candidates` 都包含它们。
- **知识库搬家或换 python 后**：重新运行 `kb connect desktop`；`kb connect status` 和 `kb doctor` 会提示路径失效。
- **移除**：`kb connect remove`；卸载时也会自动移除。
- Claude Code 命令行不需要接入。

## 配置
`~/.config/knowledge-kit/config.json`，重装不覆盖，非法值忽略：
| 键 | 默认 | 含义 |
|---|---|---|
| `similarity` | 25 | 两条记忆字面重合多少算"可能是同一件事"（0-100）；调低召回更多、误报也更多 |
| `min_projects` | 2 | 至少出现在几个项目里才算跨项目候选 |
| `topic_projects` | 3 | 同一个主题词出现在几个项目里就算信号，即使字面重合不高 |
| `stale_days` | 180 | 纠正记忆多少天没更新算可能过期 |

## 升级、迁移、卸载
- **升级**：你说"升级 knowledge-kit，新包在……"，Claude 解压后运行 `install.sh --kb <原位置>`。旧脚本和技能自动备份到 `<KB>/.upgrade-backup/`；已移除的旧脚本和技能会被清掉；数据原样保留。
- **从 0.x 迁移**：旧蒸馏流程已移除（官方记忆已经在做）；旧 inbox 保留为只读，`kb search` 仍能查；旧版写进 CLAUDE.md 的规则用 `kb rules migrate` 导入。
- **知识库搬家**：你说"把知识库搬到……"，Claude 先移动内容，再 `install.sh --kb 新路径`（技能里的路径是安装时写入的，必须重装），最后 `kb doctor`。
- **卸载**：你说"帮我卸载"，Claude 先告诉你会删什么，你同意后运行 `bash uninstall.sh --yes`。**不会删**知识库数据和 `~/.claude/rules/kb-promoted.md`。
